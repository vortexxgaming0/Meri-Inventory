import React, { useState, useRef, useEffect } from 'react';
import {
  Barcode,
  Search,
  CheckCircle,
  AlertCircle,
  CreditCard,
  Banknote,
  QrCode,
  Building2,
  User,
  Phone,
  MapPin,
  Sparkles,
  Trash2,
  Camera,
  Check,
  ShoppingBag,
  Percent,
  Receipt,
  FileCheck2,
  UserPlus,
  Edit2,
  X,
} from 'lucide-react';
import { InventoryItem, InvoiceRecord, Salesperson } from '../types';
import { INDIAN_STATES, FINANCIERS, playScannerBeep } from '../data/mockBills';

interface StockOutModuleProps {
  inventory: InventoryItem[];
  salespersons: Salesperson[];
  onSaleCompleted: (invoice: InvoiceRecord) => void;
  onSalespersonAdded?: (sp: Salesperson) => void;
  onSalespersonUpdated?: (sp: Salesperson) => void;
}

export const StockOutModule: React.FC<StockOutModuleProps> = ({
  inventory,
  salespersons,
  onSaleCompleted,
  onSalespersonAdded,
  onSalespersonUpdated,
}) => {
  // Scanned Cart
  const [scannedItems, setScannedItems] = useState<InventoryItem[]>([]);
  const [imeiInput, setImeiInput] = useState('');
  const [scanError, setScanError] = useState<string | null>(null);
  const [scanSuccess, setScanSuccess] = useState<string | null>(null);
  const [isCameraActive, setIsCameraActive] = useState(false);

  // Customer Form - starts empty and only displays what the user enters
  const [customerName, setCustomerName] = useState('');
  const [customerMobile, setCustomerMobile] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  const [selectedStateCode, setSelectedStateCode] = useState('24'); // Gujarat by default
  const [customerGstin, setCustomerGstin] = useState('');

  // Payment & Finance
  const [paymentMode, setPaymentMode] = useState<'Cash' | 'UPI' | 'Card' | 'Finance'>('UPI');
  const [selectedFinancier, setSelectedFinancier] = useState('Poonawalla Fincorp Ltd');
  const [approvalNo, setApprovalNo] = useState('');
  const [schemeCode, setSchemeCode] = useState('');

  // Salesperson selection & modals
  const [selectedSalespersonId, setSelectedSalespersonId] = useState<string>(() => salespersons[0]?.id || '');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  // Add Salesperson form state
  const [newSpName, setNewSpName] = useState('');
  const [newSpRole, setNewSpRole] = useState('Sales Executive');
  const [newSpCode, setNewSpCode] = useState('');
  const [isSavingSalesperson, setIsSavingSalesperson] = useState(false);

  // Edit Salesperson form state
  const [editSpId, setEditSpId] = useState('');
  const [editSpName, setEditSpName] = useState('');
  const [editSpRole, setEditSpRole] = useState('');
  const [editSpCode, setEditSpCode] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);

  // Derive current selected salesperson
  const selectedSalesperson = salespersons.find((s) => s.id === selectedSalespersonId) || salespersons[0] || null;

  // Auto-sync selected id if salespersons list changes
  useEffect(() => {
    if (!selectedSalespersonId && salespersons.length > 0) {
      setSelectedSalespersonId(salespersons[0].id);
    }
  }, [salespersons, selectedSalespersonId]);

  const barcodeInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  // Focus barcode input on mount
  useEffect(() => {
    barcodeInputRef.current?.focus();
  }, []);

  // Filter available stock for quick-pick chips
  const availableInventory = inventory.filter((item) => item.status === 'AVAILABLE');

  // Handle Scanning or entering IMEI
  const handleScanImei = async (imeiToLookup: string) => {
    const cleanImei = imeiToLookup.trim();
    if (!cleanImei) return;

    setScanError(null);
    setScanSuccess(null);

    // Check if already in cart
    if (scannedItems.some((it) => it.imei === cleanImei)) {
      setScanError(`IMEI ${cleanImei} is already in the current billing cart!`);
      playScannerBeep('error');
      return;
    }

    try {
      const response = await fetch(`/api/inventory/check-imei/${cleanImei}`);
      const data = await response.json();

      if (!response.ok || !data.success) {
        setScanError(data.message || `IMEI ${cleanImei} not found in inventory.`);
        playScannerBeep('error');
        return;
      }

      const item: InventoryItem = data.item;

      if (item.status === 'SOLD') {
        setScanError(`Warning: IMEI ${cleanImei} (${item.brand} ${item.model}) is already SOLD on ${item.soldDate}!`);
        playScannerBeep('error');
        return;
      }

      // Add to cart
      setScannedItems((prev) => [...prev, item]);
      setScanSuccess(`Scanned: ${item.brand} ${item.model} (${item.specs}) - ₹${item.sellingPrice.toLocaleString('en-IN')}`);
      playScannerBeep('success');
      setImeiInput('');
      barcodeInputRef.current?.focus();
    } catch (err: any) {
      setScanError('Failed to verify IMEI with server: ' + err.message);
      playScannerBeep('error');
    }
  };

  const handleRemoveFromCart = (imeiToRemove: string) => {
    setScannedItems((prev) => prev.filter((it) => it.imei !== imeiToRemove));
  };

  // Tax calculations
  const isInterState = selectedStateCode !== '24'; // Store is Gujarat (24)
  const subTotalSelling = scannedItems.reduce((sum, item) => sum + item.sellingPrice, 0);

  // Base taxable = SellingPrice / 1.18
  const subTotalTaxable = scannedItems.reduce((sum, item) => {
    const rate = item.gstPercent || 18;
    return sum + item.sellingPrice / (1 + rate / 100);
  }, 0);

  const totalGstAmount = subTotalSelling - subTotalTaxable;
  const cgstAmount = isInterState ? 0 : totalGstAmount / 2;
  const sgstAmount = isInterState ? 0 : totalGstAmount / 2;
  const igstAmount = isInterState ? totalGstAmount : 0;
  const netTotal = Math.round(subTotalSelling);

  // Complete Sale & Generate Bill
  const handleCompleteSale = async () => {
    if (scannedItems.length === 0) {
      setScanError('Please scan at least one IMEI before generating bill');
      playScannerBeep('error');
      return;
    }

    if (!customerName.trim() || !customerMobile.trim()) {
      setScanError('Please enter Customer Name and Mobile Number');
      return;
    }

    setIsSubmitting(true);
    setScanError(null);

    const currentState = INDIAN_STATES.find((s) => s.code === selectedStateCode) || INDIAN_STATES[0];

    try {
      const response = await fetch('/api/sales/complete-sale', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imeis: scannedItems.map((it) => it.imei),
          customer: {
            customerName: customerName.trim(),
            mobile: customerMobile.trim(),
            address: customerAddress.trim(),
            state: currentState.name,
            stateCode: currentState.code,
            gstin: customerGstin.trim(),
          },
          salesperson: selectedSalesperson ? selectedSalesperson.name : 'Direct Sale',
          salespersonId: selectedSalesperson ? (selectedSalesperson.code || selectedSalesperson.id) : 'STORE-01',
          paymentMode,
          financierDetails:
            paymentMode === 'Finance'
              ? {
                  financierName: selectedFinancier,
                  approvalNo,
                  schemeCode,
                }
              : undefined,
        }),
      });

      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.error || 'Failed to complete sale');
      }

      playScannerBeep('success');
      onSaleCompleted(data.invoice);
    } catch (err: any) {
      console.error('Sale error:', err);
      setScanError(err.message);
      playScannerBeep('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Add new salesperson
  const handleCreateSalesperson = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSpName.trim()) return;

    setIsSavingSalesperson(true);
    try {
      const res = await fetch('/api/salespersons', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: newSpName.trim(),
          role: newSpRole.trim() || 'Sales Executive',
          code: newSpCode.trim(),
        }),
      });
      const data = await res.json();
      if (data.success && data.salesperson) {
        onSalespersonAdded?.(data.salesperson);
        setSelectedSalespersonId(data.salesperson.id);
        setNewSpName('');
        setNewSpRole('Sales Executive');
        setNewSpCode('');
        setIsAddModalOpen(false);
        playScannerBeep('success');
      }
    } catch (err) {
      console.error('Failed to create salesperson:', err);
    } finally {
      setIsSavingSalesperson(false);
    }
  };

  // Update existing salesperson
  const handleUpdateSalesperson = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editSpName.trim() || !editSpId) return;

    setIsSavingSalesperson(true);
    try {
      const res = await fetch(`/api/salespersons/${editSpId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: editSpName.trim(),
          role: editSpRole.trim(),
          code: editSpCode.trim(),
        }),
      });
      const data = await res.json();
      if (data.success && data.salesperson) {
        onSalespersonUpdated?.(data.salesperson);
        setIsEditModalOpen(false);
        playScannerBeep('success');
      }
    } catch (err) {
      console.error('Failed to update salesperson:', err);
    } finally {
      setIsSavingSalesperson(false);
    }
  };

  // Toggle Camera Scanner simulation
  const toggleCamera = async () => {
    if (isCameraActive) {
      if (videoRef.current?.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach((track) => track.stop());
      }
      setIsCameraActive(false);
    } else {
      setIsCameraActive(true);
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment' },
        });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      } catch (e) {
        console.warn('Camera access denied or unavailable; scanner simulator active.');
      }
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* LEFT COLUMN: SCANNER & SCANNED CART (7 cols) */}
      <div className="lg:col-span-7 space-y-6">
        {/* Barcode / IMEI Scanner Card */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-indigo-50 text-indigo-700 rounded-xl">
                <Barcode className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-bold text-slate-900">Scan Barcode / IMEI</h2>
                <p className="text-xs text-slate-500">
                  Hardware barcode gun & camera scanner ready. Hit Enter or tap scan.
                </p>
              </div>
            </div>

            <button
              onClick={toggleCamera}
              className={`flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg border transition-all cursor-pointer ${
                isCameraActive
                  ? 'bg-rose-50 border-rose-300 text-rose-700'
                  : 'bg-slate-50 hover:bg-slate-100 border-slate-300 text-slate-700'
              }`}
            >
              <Camera className="w-3.5 h-3.5" />
              {isCameraActive ? 'Close Camera' : 'Camera Scan'}
            </button>
          </div>

          {/* Camera Viewfinder if active */}
          {isCameraActive && (
            <div className="mb-4 relative rounded-xl overflow-hidden bg-black aspect-video max-h-56 flex items-center justify-center border border-slate-800">
              <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
              <div className="absolute inset-0 border-2 border-indigo-400/50 m-8 rounded-lg pointer-events-none flex items-center justify-center">
                <div className="w-full h-0.5 bg-red-500 shadow-[0_0_10px_red] animate-pulse" />
              </div>
              <div className="absolute bottom-2 bg-black/70 text-white text-[10px] px-2.5 py-1 rounded-full font-mono">
                Align 1D/2D Barcode or IMEI text within frame
              </div>
            </div>
          )}

          {/* Input Form for Barcode Gun / Manual */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleScanImei(imeiInput);
            }}
            className="flex gap-2"
          >
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
              <input
                ref={barcodeInputRef}
                type="text"
                placeholder="Scan or type 15-digit IMEI (e.g. 862947051284931)..."
                value={imeiInput}
                onChange={(e) => setImeiInput(e.target.value)}
                className="w-full pl-9 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-mono focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
              />
            </div>
            <button
              type="submit"
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl font-bold text-sm transition-all shadow-sm cursor-pointer"
            >
              Lookup
            </button>
          </form>

          {/* Status feedback */}
          {scanError && (
            <div className="mt-3 p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs rounded-xl flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{scanError}</span>
            </div>
          )}

          {scanSuccess && (
            <div className="mt-3 p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-xl flex items-center gap-2">
              <CheckCircle className="w-4 h-4 shrink-0 text-emerald-600" />
              <span>{scanSuccess}</span>
            </div>
          )}

          {/* Quick Click Available Stock to Test Rapid Scanning */}
          <div className="mt-4 pt-4 border-t border-slate-200">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-700">Quick-Scan Available In-Stock Units:</span>
              <span className="text-[11px] text-slate-500">{availableInventory.length} in stock</span>
            </div>
            <div className="flex flex-wrap gap-2 max-h-32 overflow-y-auto pr-1">
              {availableInventory.length === 0 ? (
                <div className="text-xs text-slate-400 italic">
                  No available items in stock. Onboard stock via Stock IN tab first!
                </div>
              ) : (
                availableInventory.slice(0, 8).map((item) => (
                  <button
                    key={item.id}
                    onClick={() => handleScanImei(item.imei)}
                    className="inline-flex items-center gap-1.5 text-xs bg-slate-100 hover:bg-indigo-50 hover:border-indigo-300 border border-slate-200 px-2.5 py-1.5 rounded-lg text-slate-800 transition-colors cursor-pointer group"
                    title={`Click to simulate scanning ${item.brand} ${item.model}`}
                  >
                    <span className="font-semibold text-slate-900">{item.brand} {item.model}</span>
                    <span className="text-[10px] text-slate-500 font-mono">({item.imei.slice(-4)})</span>
                    <span className="text-[11px] font-bold text-emerald-700">₹{item.sellingPrice.toLocaleString('en-IN')}</span>
                  </button>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Current Billing Cart Table */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-emerald-50 text-emerald-700 rounded-xl">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">Current Sale Items ({scannedItems.length})</h3>
                <p className="text-xs text-slate-500">Auto-calculated GST taxable rate and HSN classification</p>
              </div>
            </div>
            {scannedItems.length > 0 && (
              <button
                onClick={() => setScannedItems([])}
                className="text-xs text-rose-600 hover:text-rose-800 font-semibold"
              >
                Clear Cart
              </button>
            )}
          </div>

          {scannedItems.length === 0 ? (
            <div className="text-center py-10 border-2 border-dashed border-slate-200 rounded-xl bg-slate-50/50">
              <Barcode className="w-10 h-10 text-slate-300 mx-auto mb-2" />
              <p className="text-sm font-semibold text-slate-700">No Handsets Scanned Yet</p>
              <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                Scan an IMEI using your barcode reader or tap any of the quick-scan devices above to populate the bill.
              </p>
            </div>
          ) : (
            <div className="divide-y divide-slate-200">
              {scannedItems.map((item, idx) => {
                const baseTaxable = (item.sellingPrice / 1.18).toFixed(2);
                return (
                  <div key={item.imei} className="py-3.5 flex items-center justify-between gap-4">
                    <div className="flex items-start gap-3">
                      <span className="w-6 h-6 rounded-full bg-slate-100 text-slate-600 flex items-center justify-center text-xs font-bold shrink-0">
                        {idx + 1}
                      </span>
                      <div>
                        <h4 className="text-sm font-bold text-slate-900">
                          {item.brand} {item.model}
                        </h4>
                        <div className="flex flex-wrap items-center gap-2 mt-0.5 text-xs text-slate-500">
                          <span>{item.specs}</span>
                          <span>•</span>
                          <span>{item.color}</span>
                          <span>•</span>
                          <span className="font-mono bg-slate-100 px-1.5 py-0.5 rounded text-[11px] text-slate-700 font-semibold">
                            IMEI: {item.imei}
                          </span>
                        </div>
                        <div className="text-[10px] text-slate-400 mt-1">
                          HSN: {item.hsn} | Base Rate: ₹{baseTaxable} + GST 18%
                        </div>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <div className="text-sm font-extrabold text-slate-900 font-mono">
                        ₹{item.sellingPrice.toLocaleString('en-IN')}
                      </div>
                      <button
                        onClick={() => handleRemoveFromCart(item.imei)}
                        className="text-xs text-rose-500 hover:text-rose-700 mt-1 inline-flex items-center gap-1 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        Remove
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* RIGHT COLUMN: CUSTOMER, PAYMENT MODE & FINAL TAX BILLING (5 cols) */}
      <div className="lg:col-span-5 space-y-6">
        {/* Customer Information Form */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <User className="w-4 h-4 text-indigo-600" />
            <h3 className="text-sm font-bold text-slate-900">Customer & Place of Supply</h3>
          </div>

          <div className="space-y-3">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Customer Full Name *</label>
              <input
                type="text"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                placeholder="e.g. Chirag Dave"
                className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm font-medium focus:ring-2 focus:ring-indigo-500 outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Mobile Number *</label>
                <div className="relative">
                  <span className="absolute left-2.5 top-2 text-xs text-slate-400 font-mono">+91</span>
                  <input
                    type="tel"
                    value={customerMobile}
                    onChange={(e) => setCustomerMobile(e.target.value)}
                    placeholder="9825000000"
                    className="w-full border border-slate-300 rounded-lg pl-10 pr-3 py-2 text-sm font-mono font-medium focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">State / Supply *</label>
                <select
                  value={selectedStateCode}
                  onChange={(e) => setSelectedStateCode(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg px-2.5 py-2 text-xs font-medium bg-white focus:ring-2 focus:ring-indigo-500 outline-none"
                >
                  {INDIAN_STATES.map((st) => (
                    <option key={st.code} value={st.code}>
                      {st.name} ({st.code})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Billing Address</label>
              <input
                type="text"
                value={customerAddress}
                onChange={(e) => setCustomerAddress(e.target.value)}
                placeholder="Shop/Flat No., Road, City"
                className="w-full border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-indigo-500 outline-none"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Customer GSTIN (Optional B2B)</label>
              <input
                type="text"
                value={customerGstin}
                onChange={(e) => setCustomerGstin(e.target.value.toUpperCase())}
                placeholder="e.g. 24AABCR1234F1Z5"
                className="w-full border border-slate-300 rounded-lg px-3 py-2 text-xs font-mono uppercase focus:ring-2 focus:ring-indigo-500 outline-none"
              />
            </div>
          </div>
        </div>

        {/* Payment & Finance Selector */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-indigo-600" />
              <h3 className="text-sm font-bold text-slate-900">Payment Mode</h3>
            </div>
            {paymentMode === 'Finance' && (
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-100 text-amber-800">
                Financed Loan Sale
              </span>
            )}
          </div>

          <div className="grid grid-cols-4 gap-2">
            {(['Finance', 'UPI', 'Card', 'Cash'] as const).map((mode) => (
              <button
                key={mode}
                type="button"
                onClick={() => setPaymentMode(mode)}
                className={`py-2 px-1 text-xs font-bold rounded-xl border text-center transition-all cursor-pointer ${
                  paymentMode === mode
                    ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                    : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-700'
                }`}
              >
                {mode === 'Finance' && '🏦 Finance'}
                {mode === 'UPI' && '📱 UPI'}
                {mode === 'Card' && '💳 Card'}
                {mode === 'Cash' && '💵 Cash'}
              </button>
            ))}
          </div>

          {/* Conditional Finance Fields */}
          {paymentMode === 'Finance' && (
            <div className="bg-indigo-50/60 p-4 rounded-xl border border-indigo-100 space-y-3">
              <div>
                <label className="text-xs font-bold text-indigo-950 block mb-1">Select Financer Name *</label>
                <select
                  value={selectedFinancier}
                  onChange={(e) => {
                    setSelectedFinancier(e.target.value);
                    const fin = FINANCIERS.find((f) => f.name === e.target.value);
                    if (fin) setSchemeCode(fin.defaultScheme);
                  }}
                  className="w-full bg-white border border-indigo-200 rounded-lg px-3 py-2 text-xs font-semibold text-slate-900 focus:ring-2 focus:ring-indigo-500 outline-none"
                >
                  {FINANCIERS.map((fin) => (
                    <option key={fin.id} value={fin.name}>
                      {fin.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-indigo-950 block mb-1">Approval / DO No *</label>
                  <input
                    type="text"
                    value={approvalNo}
                    onChange={(e) => setApprovalNo(e.target.value)}
                    className="w-full bg-white border border-indigo-200 rounded-lg px-2.5 py-1.5 text-xs font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-indigo-950 block mb-1">Scheme Code</label>
                  <input
                    type="text"
                    value={schemeCode}
                    onChange={(e) => setSchemeCode(e.target.value)}
                    className="w-full bg-white border border-indigo-200 rounded-lg px-2.5 py-1.5 text-xs font-medium"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Salesperson Selector */}
          <div className="pt-2">
            {salespersons.length === 0 ? (
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Salesperson</label>
                <div className="p-3.5 bg-indigo-50/80 border border-indigo-200 rounded-xl flex items-center justify-between">
                  <div>
                    <div className="text-xs font-bold text-indigo-950 flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5 text-indigo-600" />
                      No Salesperson Added
                    </div>
                    <div className="text-[11px] text-indigo-700 mt-0.5">
                      Add counter staff to record on tax invoices
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setIsAddModalOpen(true)}
                    className="inline-flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs px-3 py-1.5 rounded-lg transition-all cursor-pointer shadow-xs"
                  >
                    <UserPlus className="w-3.5 h-3.5" />
                    Add a Salesperson
                  </button>
                </div>
              </div>
            ) : (
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-slate-700">Salesperson</label>
                  <div className="flex items-center gap-2">
                    {selectedSalesperson && (
                      <button
                        type="button"
                        onClick={() => {
                          setEditSpId(selectedSalesperson.id);
                          setEditSpName(selectedSalesperson.name);
                          setEditSpRole(selectedSalesperson.role || '');
                          setEditSpCode(selectedSalesperson.code || '');
                          setIsEditModalOpen(true);
                        }}
                        className="inline-flex items-center gap-1 text-[11px] text-indigo-600 hover:text-indigo-800 font-semibold cursor-pointer"
                      >
                        <Edit2 className="w-3 h-3" />
                        Edit Name
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => setIsAddModalOpen(true)}
                      className="inline-flex items-center gap-1 text-[11px] text-slate-600 hover:text-slate-900 font-semibold cursor-pointer"
                    >
                      <UserPlus className="w-3 h-3" />
                      + Add
                    </button>
                  </div>
                </div>
                <select
                  value={selectedSalesperson?.id || ''}
                  onChange={(e) => setSelectedSalespersonId(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 text-xs font-medium bg-white focus:ring-2 focus:ring-indigo-500 outline-none"
                >
                  {salespersons.map((sp) => (
                    <option key={sp.id} value={sp.id}>
                      {sp.name} {sp.code ? `(${sp.code})` : ''} {sp.role ? `• ${sp.role}` : ''}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>
        </div>

        {/* Tax Breakdown & Checkout Card */}
        <div className="bg-slate-900 text-white rounded-2xl p-6 shadow-lg space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold flex items-center gap-2">
              <Receipt className="w-4 h-4 text-emerald-400" />
              Tax Invoice Breakdown
            </h3>
            <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-slate-800 text-slate-300">
              {isInterState ? 'Inter-State (IGST 18%)' : 'Intra-State (CGST 9% + SGST 9%)'}
            </span>
          </div>

          <div className="space-y-2 text-xs text-slate-300">
            <div className="flex justify-between">
              <span>Base Taxable Amount:</span>
              <span className="font-mono text-white font-semibold">
                ₹{subTotalTaxable.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>

            {isInterState ? (
              <div className="flex justify-between text-indigo-300">
                <span>Integrated Tax (IGST @ 18%):</span>
                <span className="font-mono font-semibold">
                  ₹{igstAmount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
              </div>
            ) : (
              <>
                <div className="flex justify-between text-indigo-300">
                  <span>Central GST (CGST @ 9%):</span>
                  <span className="font-mono font-semibold">
                    ₹{cgstAmount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>
                <div className="flex justify-between text-indigo-300">
                  <span>State GST (SGST @ 9%):</span>
                  <span className="font-mono font-semibold">
                    ₹{sgstAmount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>
              </>
            )}

            <div className="border-t border-slate-800 pt-2 flex justify-between items-baseline text-white">
              <span className="text-sm font-bold">Net Payable Total:</span>
              <span className="text-2xl font-black font-mono text-emerald-400">
                ₹{netTotal.toLocaleString('en-IN')}
              </span>
            </div>
          </div>

          <button
            onClick={handleCompleteSale}
            disabled={isSubmitting || scannedItems.length === 0}
            className="w-full py-3.5 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-black text-sm rounded-xl transition-all shadow-lg flex items-center justify-center gap-2 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <FileCheck2 className="w-5 h-5 text-slate-950" />
            {isSubmitting ? 'Finalizing Invoice...' : 'Generate Bill / Complete Sale'}
          </button>
        </div>
      </div>

      {/* --- ADD SALESPERSON MODAL --- */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 border border-slate-200 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <UserPlus className="w-4 h-4 text-indigo-600" />
                Add New Salesperson
              </h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateSalesperson} className="space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Salesperson Full Name *
                </label>
                <input
                  type="text"
                  required
                  value={newSpName}
                  onChange={(e) => setNewSpName(e.target.value)}
                  placeholder="e.g. Rahul Sharma"
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:ring-2 focus:ring-indigo-500 outline-none"
                  autoFocus
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Role / Title (Optional)
                </label>
                <input
                  type="text"
                  value={newSpRole}
                  onChange={(e) => setNewSpRole(e.target.value)}
                  placeholder="e.g. Sales Executive, Store Manager"
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Employee ID / Code (Optional)
                </label>
                <input
                  type="text"
                  value={newSpCode}
                  onChange={(e) => setNewSpCode(e.target.value)}
                  placeholder="e.g. EMP-101"
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 text-xs font-mono uppercase text-slate-900 focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSavingSalesperson || !newSpName.trim()}
                  className="px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all cursor-pointer shadow-xs disabled:opacity-50"
                >
                  {isSavingSalesperson ? 'Saving...' : 'Add Salesperson'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --- EDIT SALESPERSON MODAL --- */}
      {isEditModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 border border-slate-200 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Edit2 className="w-4 h-4 text-indigo-600" />
                Edit Salesperson Name
              </h3>
              <button
                onClick={() => setIsEditModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleUpdateSalesperson} className="space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Salesperson Full Name *
                </label>
                <input
                  type="text"
                  required
                  value={editSpName}
                  onChange={(e) => setEditSpName(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 text-xs font-bold text-slate-900 focus:ring-2 focus:ring-indigo-500 outline-none"
                  autoFocus
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Role / Title
                </label>
                <input
                  type="text"
                  value={editSpRole}
                  onChange={(e) => setEditSpRole(e.target.value)}
                  placeholder="e.g. Senior Consultant"
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Employee ID / Code
                </label>
                <input
                  type="text"
                  value={editSpCode}
                  onChange={(e) => setEditSpCode(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 text-xs font-mono uppercase text-slate-900 focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsEditModalOpen(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSavingSalesperson || !editSpName.trim()}
                  className="px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all cursor-pointer shadow-xs disabled:opacity-50"
                >
                  {isSavingSalesperson ? 'Saving...' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
