import React, { useState, useEffect, useRef } from 'react';
import {
  Smartphone,
  ShieldCheck,
  Building2,
  Store,
  CheckCircle2,
  ArrowRight,
  ArrowLeft,
  KeyRound,
  FileText,
  Percent,
  Sparkles,
  Layers,
  Wrench,
  Globe,
  HelpCircle,
  AlertCircle,
  MessageSquare,
  Check,
  TrendingUp,
  Package,
} from 'lucide-react';
import { INDIAN_STATES, playScannerBeep } from '../data/mockBills';
import { StoreProfile, ShopCategory, UserSession } from '../types';
import { MeriLogo } from './MeriLogo';

interface AuthAndOnboardingProps {
  onAuthSuccess: (session: UserSession, store: StoreProfile) => void;
  currentStore?: StoreProfile | null;
}

export const AuthAndOnboarding: React.FC<AuthAndOnboardingProps> = ({ onAuthSuccess, currentStore }) => {
  // Splash Screen State
  const [splashPhase, setSplashPhase] = useState<'SPLASH' | 'LOGIN'>('SPLASH');

  // Mode: 'MOBILE' -> 'OTP' -> 'ONBOARDING'
  const [authStep, setAuthStep] = useState<'MOBILE' | 'OTP' | 'ONBOARDING'>('MOBILE');

  // Mobile & OTP state - starts empty
  const [mobile, setMobile] = useState('');
  const [latestOtp, setLatestOtp] = useState<string>('');
  const [otpDigits, setOtpDigits] = useState<string[]>(['', '', '', '', '', '']);
  const [simulatedSms, setSimulatedSms] = useState<string | null>(null);
  const [resendTimer, setResendTimer] = useState(30);
  const [isSendingOtp, setIsSendingOtp] = useState(false);
  const [isVerifyingOtp, setIsVerifyingOtp] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  // Progressive Onboarding Wizard state (Step 1 to 4)
  const [wizardStep, setWizardStep] = useState<1 | 2 | 3 | 4>(1);

  // Form Fields - starts completely empty and only displays what the user enters
  const [shopCategory, setShopCategory] = useState<ShopCategory>(currentStore?.category || 'RETAIL');
  const [storeScale, setStoreScale] = useState<'SOLO' | 'SMALL' | 'ENTERPRISE'>('SOLO');
  const [shopName, setShopName] = useState(currentStore?.isConfigured ? currentStore.name : '');
  const [ownerName, setOwnerName] = useState(currentStore?.isConfigured ? currentStore.ownerName : '');
  const [shopNo, setShopNo] = useState(currentStore?.isConfigured ? currentStore.shopNo : '');
  const [address, setAddress] = useState(currentStore?.isConfigured ? currentStore.address : '');
  const [city, setCity] = useState(currentStore?.isConfigured ? currentStore.city : '');
  const [selectedStateCode, setSelectedStateCode] = useState(currentStore?.stateCode || '24');
  const [email, setEmail] = useState(currentStore?.isConfigured ? currentStore.email : '');

  // GST Registration (Strictly Optional) - starts as false/empty
  const [hasGst, setHasGst] = useState<boolean>(currentStore?.isConfigured ? currentStore.hasGst : false);
  const [gstin, setGstin] = useState(currentStore?.isConfigured ? (currentStore.gstin || '') : '');
  const [pan, setPan] = useState(currentStore?.isConfigured ? (currentStore.pan || '') : '');
  const [invoicePrefix, setInvoicePrefix] = useState(currentStore?.isConfigured ? currentStore.invoicePrefix : 'INV-');

  const [isSavingSetup, setIsSavingSetup] = useState(false);
  const otpInputRefs = useRef<(HTMLInputElement | null)[]>([]);

  // Automatic transition from Splash to Login after animation sequence
  useEffect(() => {
    const timer = setTimeout(() => {
      setSplashPhase('LOGIN');
    }, 1800);
    return () => clearTimeout(timer);
  }, []);

  // OTP Resend Countdown
  useEffect(() => {
    let interval: any;
    if (authStep === 'OTP' && resendTimer > 0) {
      interval = setInterval(() => {
        setResendTimer((t) => t - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [authStep, resendTimer]);

  // Auto extract PAN from GSTIN if 15 chars
  useEffect(() => {
    if (gstin && gstin.length >= 12) {
      const extractedPan = gstin.substring(2, 12).toUpperCase();
      if (/^[A-Z]{5}[0-9]{4}[A-Z]$/.test(extractedPan)) {
        setPan(extractedPan);
      }
    }
  }, [gstin]);

  // Send OTP
  const handleSendOtp = async (customMobile?: string) => {
    const targetMobile = (customMobile || mobile).replace(/\D/g, '');
    if (targetMobile.length < 10) {
      setAuthError('Please enter a valid 10-digit mobile number');
      playScannerBeep('error');
      return;
    }

    setIsSendingOtp(true);
    setAuthError(null);

    try {
      const res = await fetch('/api/auth/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mobile: targetMobile }),
      });
      const data = await res.json();

      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to send OTP');
      }

      const code = String(data.otp || data.otpDemo || '');
      setLatestOtp(code);
      setMobile(targetMobile);
      setSimulatedSms(`Your Meri Inventory verification code is: ${code}. Valid for 5 minutes.`);
      setAuthStep('OTP');
      setResendTimer(30);
      playScannerBeep();

      // Autofocus first OTP box
      setTimeout(() => {
        otpInputRefs.current[0]?.focus();
      }, 200);
    } catch (err: any) {
      setAuthError(err.message);
      playScannerBeep('error');
    } finally {
      setIsSendingOtp(false);
    }
  };

  // OTP inputs handler
  const handleOtpChange = (index: number, value: string) => {
    const val = value.replace(/\D/g, '');
    if (!val && value !== '') return;

    const newDigits = [...otpDigits];
    newDigits[index] = val.slice(-1);
    setOtpDigits(newDigits);

    // Auto advance to next input box
    if (val && index < 5) {
      otpInputRefs.current[index + 1]?.focus();
    }
  };

  const handleOtpKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !otpDigits[index] && index > 0) {
      otpInputRefs.current[index - 1]?.focus();
    }
  };

  const handleAutoFillOtp = () => {
    const code = latestOtp || simulatedSms?.match(/\b\d{6}\b/)?.[0];
    if (code && code.length === 6) {
      setOtpDigits(code.split(''));
      playScannerBeep('success');
    }
  };

  // Verify OTP
  const handleVerifyOtp = async () => {
    const code = otpDigits.join('');
    if (code.length < 6) {
      setAuthError('Please enter full 6-digit OTP code');
      playScannerBeep('error');
      return;
    }

    setIsVerifyingOtp(true);
    setAuthError(null);

    try {
      const res = await fetch('/api/auth/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mobile, otp: code }),
      });
      const data = await res.json();

      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Invalid or expired OTP');
      }

      playScannerBeep('success');

      // Check if store is already setup on server
      if (data.store && data.store.isConfigured && data.store.name) {
        onAuthSuccess({ mobile, isLoggedIn: true, token: data.session?.token }, data.store);
      } else {
        // Proceed to Progressive Onboarding
        setAuthStep('ONBOARDING');
      }
    } catch (err: any) {
      setAuthError(err.message);
      playScannerBeep('error');
    } finally {
      setIsVerifyingOtp(false);
    }
  };

  // Submit Final Store Setup
  const handleFinishSetup = async () => {
    if (!shopName.trim()) {
      setAuthError('Please enter your Shop / Store Name');
      setWizardStep(2);
      playScannerBeep('error');
      return;
    }

    setIsSavingSetup(true);
    setAuthError(null);

    const st = INDIAN_STATES.find((s) => s.code === selectedStateCode) || INDIAN_STATES[0];

    try {
      const res = await fetch('/api/store/setup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: shopName.trim(),
          category: shopCategory,
          ownerName: ownerName.trim(),
          mobile,
          email: email.trim(),
          shopNo: shopNo.trim(),
          address: address.trim(),
          city: city.trim(),
          state: st.name,
          stateCode: st.code,
          hasGst,
          gstin: hasGst ? gstin.trim().toUpperCase() : undefined,
          pan: hasGst ? pan.trim().toUpperCase() : undefined,
          invoicePrefix: invoicePrefix.trim() || 'INV-',
        }),
      });
      const data = await res.json();

      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to save store profile');
      }

      playScannerBeep('success');
      onAuthSuccess({ mobile, isLoggedIn: true }, data.store);
    } catch (err: any) {
      setAuthError(err.message);
      playScannerBeep('error');
    } finally {
      setIsSavingSetup(false);
    }
  };

  // =========================================================================
  // 1. SPLASH SCREEN (ANIMATED LOGO DISPLAY FIRST)
  // =========================================================================
  if (splashPhase === 'SPLASH') {
    return (
      <div
        onClick={() => setSplashPhase('LOGIN')}
        className="min-h-screen bg-[#F0FAF8] flex flex-col justify-center items-center p-6 select-none cursor-pointer relative overflow-hidden font-sans"
      >
        {/* Subtle Watermark Diagrams matching reference image */}
        <div className="absolute inset-0 pointer-events-none opacity-40 overflow-hidden">
          {/* Top Right Floating Chart & QR icon watermark */}
          <div className="absolute top-12 right-12 w-48 h-32 border-2 border-dashed border-teal-200/60 rounded-2xl p-3 transform rotate-6">
            <div className="flex gap-1.5 h-full items-end pb-2">
              <div className="w-4 bg-teal-200/50 h-1/3 rounded-t" />
              <div className="w-4 bg-teal-200/50 h-2/3 rounded-t" />
              <div className="w-4 bg-teal-200/50 h-full rounded-t" />
              <div className="w-4 bg-teal-200/50 h-1/2 rounded-t" />
            </div>
          </div>

          {/* Bottom Left Faint Box Wireframe */}
          <div className="absolute bottom-8 left-8 w-60 h-44 border-2 border-teal-200/40 rounded-3xl p-4 transform -rotate-12 flex items-center justify-center">
            <Package className="w-24 h-24 text-teal-200/40" />
          </div>

          {/* Faint Glow Circles */}
          <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-96 h-96 bg-teal-300/20 blur-3xl rounded-full" />
          <div className="absolute bottom-20 right-1/4 w-80 h-80 bg-orange-300/15 blur-3xl rounded-full" />
        </div>

        {/* Centered Animated Logo */}
        <div className="relative z-10 flex flex-col items-center animate-logo-entrance">
          <div className="animate-float-gentle">
            <MeriLogo size="xl" animated={true} showText={true} />
          </div>

          {/* Subtitle tag */}
          <div className="mt-8 flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/80 border border-teal-200/80 shadow-xs text-xs font-bold text-[#0D5C58]">
            <Sparkles className="w-3.5 h-3.5 text-[#E67E22] animate-shimmer-sparkle" />
            <span>Smart Retail POS & Inventory Suite</span>
          </div>

          {/* Skip prompt hint */}
          <p className="text-[11px] text-teal-700/60 mt-4 animate-pulse">
            Tap anywhere to begin
          </p>
        </div>
      </div>
    );
  }

  // =========================================================================
  // 2. MAIN LOGIN & ONBOARDING INTERFACE (WITH LOGO & TRANSITION)
  // =========================================================================
  return (
    <div className="min-h-screen bg-[#F0FAF8] text-slate-800 flex flex-col justify-center items-center p-4 sm:p-6 font-sans relative overflow-hidden">
      {/* Background Watermark Shapes */}
      <div className="fixed inset-0 pointer-events-none opacity-30 overflow-hidden">
        <div className="absolute top-8 right-8 w-56 h-40 border-2 border-teal-200/50 rounded-2xl p-4 transform rotate-6" />
        <div className="absolute bottom-10 left-10 w-72 h-48 border-2 border-teal-200/40 rounded-3xl transform -rotate-6" />
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[350px] bg-teal-200/30 blur-[100px] rounded-full" />
      </div>

      <div className="relative z-10 w-full max-w-md sm:max-w-lg">
        {/* Animated Brand Logo in Top Position */}
        <div className="text-center mb-6">
          <div className="inline-block transform hover:scale-105 transition-transform duration-300">
            <MeriLogo size="md" animated={false} showText={true} />
          </div>
        </div>

        {/* Global Error Banner */}
        {authError && (
          <div className="mb-4 bg-rose-50 border border-rose-200 text-rose-800 p-3.5 rounded-2xl text-xs flex items-center gap-2.5 shadow-xs animate-shake">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
            <span className="font-semibold">{authError}</span>
          </div>
        )}

        {/* =========================================================================
            PHASE 1: MOBILE NUMBER & OTP LOGIN CARD (SLIDE-IN ANIMATION)
            ========================================================================= */}
        {authStep !== 'ONBOARDING' && (
          <div className="bg-white/95 backdrop-blur-md border border-teal-100/90 rounded-3xl p-6 sm:p-8 shadow-xl shadow-teal-900/5 space-y-6 animate-card-slide-up">
            {authStep === 'MOBILE' && (
              <div className="space-y-5">
                <div>
                  <h2 className="text-xl font-black text-[#0D5C58] tracking-tight">
                    Enter your Mobile Number
                  </h2>
                  <p className="text-xs text-slate-500 mt-1">
                    Sign in to access your retail inventory, barcode scanner, and GST billing.
                  </p>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1.5">
                    Mobile Number *
                  </label>
                  <div className="flex gap-2.5">
                    <div className="flex items-center gap-1.5 px-3.5 py-3 bg-teal-50/70 border border-teal-200 rounded-2xl text-xs font-bold text-[#0D5C58] shrink-0">
                      <span>🇮🇳 +91</span>
                    </div>
                    <input
                      type="tel"
                      value={mobile}
                      onChange={(e) => setMobile(e.target.value.replace(/\D/g, '').slice(0, 10))}
                      placeholder="Enter 10-digit mobile number"
                      autoFocus
                      className="flex-1 px-4 py-3 bg-slate-50 border border-slate-200 focus:bg-white rounded-2xl text-base font-mono font-bold text-slate-900 focus:ring-2 focus:ring-[#0D9488] focus:border-[#0D9488] outline-none transition-all placeholder:text-slate-400 placeholder:font-normal"
                    />
                  </div>
                </div>

                {/* Main Clickable Login Button */}
                <button
                  onClick={() => handleSendOtp()}
                  disabled={isSendingOtp || mobile.length < 10}
                  className="w-full py-3.5 bg-gradient-to-r from-[#0D9488] to-[#0F766E] hover:from-[#14B8A6] hover:to-[#0D9488] text-white font-black text-sm rounded-2xl transition-all shadow-md shadow-teal-700/25 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 mt-2"
                >
                  {isSendingOtp ? 'Sending OTP Code...' : 'Continue with Mobile OTP'}
                  <ArrowRight className="w-4 h-4 text-white" />
                </button>
              </div>
            )}

            {authStep === 'OTP' && (
              <div className="space-y-5 animate-card-slide-up">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-xl font-black text-[#0D5C58] flex items-center gap-2 tracking-tight">
                      <KeyRound className="w-5 h-5 text-[#E67E22]" />
                      Verify 6-Digit OTP
                    </h2>
                    <p className="text-xs text-slate-500 mt-1">
                      Sent to <strong className="text-slate-900">+91 {mobile}</strong>
                    </p>
                  </div>
                  <button
                    onClick={() => setAuthStep('MOBILE')}
                    className="text-xs text-[#E67E22] hover:text-orange-700 font-bold cursor-pointer underline"
                  >
                    Change Number
                  </button>
                </div>

                {/* SMS Notification Banner with Clear OTP Code */}
                {simulatedSms && (
                  <div className="bg-teal-50 border-2 border-teal-300 p-4 rounded-2xl flex items-center justify-between gap-3 text-xs shadow-xs">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-[#0D9488] rounded-xl text-white shadow-2xs shrink-0">
                        <MessageSquare className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="font-bold text-[#0D5C58] text-xs">SMS Verification Code:</div>
                        <div className="text-lg font-black font-mono tracking-widest text-[#E67E22] mt-0.5">
                          {latestOtp || simulatedSms.match(/\b\d{6}\b/)?.[0] || '449210'}
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={handleAutoFillOtp}
                      type="button"
                      className="shrink-0 bg-[#E67E22] hover:bg-orange-600 text-white font-black text-xs px-3.5 py-2 rounded-xl transition-all cursor-pointer shadow-xs flex items-center gap-1.5"
                    >
                      <Check className="w-3.5 h-3.5" />
                      Auto-Fill OTP
                    </button>
                  </div>
                )}

                {/* 6 Digit Input Boxes */}
                <div className="flex justify-between gap-2 sm:gap-3 my-4">
                  {otpDigits.map((digit, idx) => (
                    <input
                      key={idx}
                      ref={(el) => {
                        otpInputRefs.current[idx] = el;
                      }}
                      type="text"
                      inputMode="numeric"
                      maxLength={1}
                      value={digit}
                      onChange={(e) => handleOtpChange(idx, e.target.value)}
                      onKeyDown={(e) => handleOtpKeyDown(idx, e)}
                      className="w-11 sm:w-13 h-13 sm:h-15 text-center text-xl font-black font-mono bg-slate-50 border border-slate-300 rounded-2xl text-slate-900 focus:bg-white focus:ring-2 focus:ring-[#0D9488] focus:border-[#0D9488] outline-none transition-all shadow-inner"
                    />
                  ))}
                </div>

                <div className="flex items-center justify-between text-xs text-slate-500">
                  <span>Didn&apos;t receive code?</span>
                  {resendTimer > 0 ? (
                    <span className="font-mono text-slate-400">Resend in {resendTimer}s</span>
                  ) : (
                    <button
                      onClick={() => handleSendOtp()}
                      className="text-[#0D9488] hover:text-teal-800 font-bold cursor-pointer"
                    >
                      Resend OTP
                    </button>
                  )}
                </div>

                <button
                  onClick={() => handleVerifyOtp()}
                  disabled={isVerifyingOtp || otpDigits.some((d) => !d)}
                  className="w-full py-3.5 bg-gradient-to-r from-[#0D9488] to-[#0F766E] hover:from-[#14B8A6] hover:to-[#0D9488] text-white font-black text-sm rounded-2xl transition-all shadow-md shadow-teal-700/25 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {isVerifyingOtp ? 'Verifying OTP...' : 'Verify & Open Terminal'}
                  <Check className="w-4 h-4 text-white" />
                </button>
              </div>
            )}
          </div>
        )}

        {/* =========================================================================
            PHASE 2: PROGRESSIVE MULTI-STEP STORE SETUP WIZARD
            ========================================================================= */}
        {authStep === 'ONBOARDING' && (
          <div className="bg-white/95 backdrop-blur-md border border-teal-100 rounded-3xl p-6 sm:p-8 shadow-xl shadow-teal-900/5 space-y-6 animate-card-slide-up">
            {/* Stepper Progress Header */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-[#E67E22] uppercase tracking-wider">
                  Step {wizardStep} of 4 • Store Onboarding
                </span>
                <span className="text-xs text-[#0D5C58] font-bold">
                  {wizardStep === 1 && 'Store Category'}
                  {wizardStep === 2 && 'Business Identity'}
                  {wizardStep === 3 && 'GST (Optional)'}
                  {wizardStep === 4 && 'Invoice Format'}
                </span>
              </div>
              <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-gradient-to-r from-[#0D9488] to-[#E67E22] h-full transition-all duration-300"
                  style={{ width: `${(wizardStep / 4) * 100}%` }}
                />
              </div>
            </div>

            {/* STEP 1: SHOP CATEGORY & SCALE */}
            {wizardStep === 1 && (
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-black text-[#0D5C58]">Select Shop Category</h3>
                  <p className="text-xs text-slate-500">
                    Customizes default HSN codes (8517), GST rates (18%), and mobile IMEI tracking.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {[
                    {
                      id: 'RETAIL',
                      label: 'Retail Store',
                      desc: 'Smartphones, accessories, tablets & quick customer billing',
                      icon: Smartphone,
                      tag: 'Popular',
                    },
                    {
                      id: 'WHOLESALE',
                      label: 'Wholesale Distributor',
                      desc: 'Bulk stock IN, carton & box IMEI distribution to retailers',
                      icon: Layers,
                      tag: 'B2B',
                    },
                    {
                      id: 'RETAIL_SERVICE',
                      label: 'Retail & Service Center',
                      desc: 'Device sales plus repair job-sheets & spare parts stock',
                      icon: Wrench,
                      tag: 'Sales + Repair',
                    },
                    {
                      id: 'ONLINE_HYBRID',
                      label: 'Omnichannel Hybrid',
                      desc: 'Walk-in retail + WhatsApp catalogue & direct courier dispatch',
                      icon: Globe,
                      tag: 'E-Commerce',
                    },
                  ].map((cat) => {
                    const IconComponent = cat.icon;
                    const isSelected = shopCategory === cat.id;
                    return (
                      <div
                        key={cat.id}
                        onClick={() => setShopCategory(cat.id as ShopCategory)}
                        className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
                          isSelected
                            ? 'bg-teal-50/80 border-[#0D9488] ring-2 ring-[#0D9488]'
                            : 'bg-slate-50/70 border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <div>
                          <div className="flex items-center justify-between">
                            <div className={`p-2 rounded-xl ${isSelected ? 'bg-[#0D9488] text-white' : 'bg-slate-200 text-slate-600'}`}>
                              <IconComponent className="w-4 h-4" />
                            </div>
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-200 text-slate-700">
                              {cat.tag}
                            </span>
                          </div>
                          <h4 className="font-bold text-slate-900 text-sm mt-2.5">{cat.label}</h4>
                          <p className="text-xs text-slate-500 mt-1 leading-snug">{cat.desc}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div className="pt-4 flex justify-end">
                  <button
                    onClick={() => setWizardStep(2)}
                    className="flex items-center gap-2 bg-[#0D9488] hover:bg-teal-700 text-white font-bold text-xs px-5 py-2.5 rounded-xl transition-all cursor-pointer shadow-xs"
                  >
                    <span>Next: Store Identity</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* STEP 2: BUSINESS IDENTITY & ADDRESS */}
            {wizardStep === 2 && (
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-black text-[#0D5C58]">Store Identity & Address</h3>
                  <p className="text-xs text-slate-500">
                    This business name will appear at the top of your homepage and on customer tax invoices.
                  </p>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">
                      Store / Business Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={shopName}
                      onChange={(e) => setShopName(e.target.value)}
                      placeholder="e.g. SHIVAM MOBILE & TECH"
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm font-bold text-slate-900 focus:bg-white focus:ring-2 focus:ring-[#0D9488] outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-bold text-slate-700 block mb-1">Owner Name</label>
                      <input
                        type="text"
                        value={ownerName}
                        onChange={(e) => setOwnerName(e.target.value)}
                        placeholder="e.g. Chirag Patel"
                        className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900 focus:ring-2 focus:ring-[#0D9488] outline-none"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-slate-700 block mb-1">Shop / Unit No.</label>
                      <input
                        type="text"
                        value={shopNo}
                        onChange={(e) => setShopNo(e.target.value)}
                        placeholder="e.g. Shop 14, Ground Floor"
                        className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900 focus:ring-2 focus:ring-[#0D9488] outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">Street Address</label>
                    <input
                      type="text"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      placeholder="e.g. Station Road, Near Central Plaza"
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900 focus:ring-2 focus:ring-[#0D9488] outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-bold text-slate-700 block mb-1">City *</label>
                      <input
                        type="text"
                        required
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        placeholder="e.g. Ahmedabad"
                        className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900 focus:ring-2 focus:ring-[#0D9488] outline-none"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-slate-700 block mb-1">State (Supply)</label>
                      <select
                        value={selectedStateCode}
                        onChange={(e) => setSelectedStateCode(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-300 rounded-xl px-2.5 py-2 text-xs text-slate-900 focus:ring-2 focus:ring-[#0D9488] outline-none"
                      >
                        {INDIAN_STATES.map((s) => (
                          <option key={s.code} value={s.code}>
                            {s.name} ({s.code})
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>

                <div className="pt-4 flex justify-between">
                  <button
                    onClick={() => setWizardStep(1)}
                    className="flex items-center gap-1.5 text-xs text-slate-600 hover:text-slate-900 font-semibold cursor-pointer"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    Back
                  </button>
                  <button
                    onClick={() => {
                      if (!shopName.trim()) {
                        setAuthError('Please enter Store Name');
                        return;
                      }
                      setAuthError(null);
                      setWizardStep(3);
                    }}
                    className="flex items-center gap-2 bg-[#0D9488] hover:bg-teal-700 text-white font-bold text-xs px-5 py-2.5 rounded-xl transition-all cursor-pointer shadow-xs"
                  >
                    <span>Next: GST Settings</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* STEP 3: GST DETAILS (STRICTLY OPTIONAL) */}
            {wizardStep === 3 && (
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-black text-[#0D5C58]">GST Registration (Optional)</h3>
                  <p className="text-xs text-slate-500">
                    If you are a non-GST or composition dealer, leave this turned off.
                  </p>
                </div>

                <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-bold text-slate-900 text-xs">Does your store have a GSTIN?</div>
                      <div className="text-[11px] text-slate-500">Regular dealer with input tax credit (ITC)</div>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={hasGst}
                        onChange={(e) => setHasGst(e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#0D9488]"></div>
                    </label>
                  </div>

                  {hasGst && (
                    <div className="space-y-3 pt-3 border-t border-slate-200">
                      <div>
                        <label className="text-xs font-bold text-slate-700 block mb-1">
                          GSTIN (15 Digits)
                        </label>
                        <input
                          type="text"
                          maxLength={15}
                          value={gstin}
                          onChange={(e) => setGstin(e.target.value.toUpperCase())}
                          placeholder="e.g. 24AAECS9124L1ZM"
                          className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono uppercase font-bold text-slate-900 focus:ring-2 focus:ring-[#0D9488] outline-none"
                        />
                      </div>
                      <div>
                        <label className="text-xs font-bold text-slate-700 block mb-1">PAN Number</label>
                        <input
                          type="text"
                          maxLength={10}
                          value={pan}
                          onChange={(e) => setPan(e.target.value.toUpperCase())}
                          placeholder="e.g. AAECS9124L"
                          className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono uppercase text-slate-900 focus:ring-2 focus:ring-[#0D9488] outline-none"
                        />
                      </div>
                    </div>
                  )}
                </div>

                <div className="pt-4 flex justify-between">
                  <button
                    onClick={() => setWizardStep(2)}
                    className="flex items-center gap-1.5 text-xs text-slate-600 hover:text-slate-900 font-semibold cursor-pointer"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    Back
                  </button>
                  <button
                    onClick={() => setWizardStep(4)}
                    className="flex items-center gap-2 bg-[#0D9488] hover:bg-teal-700 text-white font-bold text-xs px-5 py-2.5 rounded-xl transition-all cursor-pointer shadow-xs"
                  >
                    <span>Next: Invoice Numbering</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* STEP 4: INVOICE PREFIX & CONFIRMATION */}
            {wizardStep === 4 && (
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-black text-[#0D5C58]">Invoice Prefix & Finish</h3>
                  <p className="text-xs text-slate-500">
                    Set your bill numbering sequence format for printed and WhatsApp invoices.
                  </p>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">
                      Invoice Prefix (e.g. INV-2026-)
                    </label>
                    <input
                      type="text"
                      value={invoicePrefix}
                      onChange={(e) => setInvoicePrefix(e.target.value.toUpperCase())}
                      placeholder="INV-2026-"
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono uppercase font-bold text-slate-900 focus:ring-2 focus:ring-[#0D9488] outline-none"
                    />
                  </div>

                  <div className="p-3.5 bg-teal-50 border border-teal-200 rounded-2xl text-xs space-y-1 text-slate-700">
                    <div className="font-bold text-[#0D5C58] flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-[#0D9488]" />
                      Store Summary Ready
                    </div>
                    <div>Store: <strong>{shopName || 'Retail Store'}</strong></div>
                    <div>Location: <strong>{city || 'Ahmedabad'}, {INDIAN_STATES.find(s => s.code === selectedStateCode)?.name}</strong></div>
                    <div>Tax Mode: <strong>{hasGst ? `GST Registered (${gstin || 'Pending'})` : 'Composition / Non-GST Retail'}</strong></div>
                  </div>
                </div>

                <div className="pt-4 flex justify-between">
                  <button
                    onClick={() => setWizardStep(3)}
                    className="flex items-center gap-1.5 text-xs text-slate-600 hover:text-slate-900 font-semibold cursor-pointer"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    Back
                  </button>
                  <button
                    onClick={handleFinishSetup}
                    disabled={isSavingSetup}
                    className="flex items-center gap-2 bg-gradient-to-r from-[#0D9488] to-[#0F766E] hover:from-[#14B8A6] hover:to-[#0D9488] text-white font-black text-xs px-6 py-2.5 rounded-xl transition-all cursor-pointer shadow-md disabled:opacity-50"
                  >
                    <span>{isSavingSetup ? 'Creating Store...' : 'Complete Setup & Launch POS'}</span>
                    <Check className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
