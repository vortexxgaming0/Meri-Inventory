import React, { useState } from 'react';
import {
  X,
  Smartphone,
  ExternalLink,
  Copy,
  Check,
  ShieldCheck,
  Download,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Layers,
  Globe,
  Key,
} from 'lucide-react';

interface PlayStorePublishModalProps {
  isOpen: boolean;
  onClose: () => void;
  publicUrl: string;
}

export const PlayStorePublishModal: React.FC<PlayStorePublishModalProps> = ({
  isOpen,
  onClose,
  publicUrl,
}) => {
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [shaInput, setShaInput] = useState('');
  const [isUpdatingSha, setIsUpdatingSha] = useState(false);
  const [shaSuccessMsg, setShaSuccessMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(publicUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  const pwaBuilderUrl = `https://www.pwabuilder.com/reportcard?site=${encodeURIComponent(publicUrl)}`;

  const handleUpdateSha = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!shaInput.trim()) return;

    setIsUpdatingSha(true);
    setShaSuccessMsg(null);
    try {
      const res = await fetch('/api/playstore/update-assetlinks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sha256: shaInput.trim() }),
      });
      const data = await res.json();
      if (data.success) {
        setShaSuccessMsg('SHA-256 fingerprint registered in /.well-known/assetlinks.json');
        setShaInput('');
        setTimeout(() => setShaSuccessMsg(null), 3000);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsUpdatingSha(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-600 flex items-center justify-center text-white shadow-md shadow-emerald-500/20">
              <Smartphone className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-black text-slate-900 text-lg">Google Play Store Build & Export</h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
                  Ready (.AAB)
                </span>
              </div>
              <p className="text-xs text-slate-500">
                PWA to Android App Bundle (.aab) generation for Google Play Console submission
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-2 rounded-xl hover:bg-slate-100 cursor-pointer transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Public Live URL Card */}
        <div className="bg-indigo-50/70 p-4 rounded-2xl border border-indigo-100 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-indigo-950 flex items-center gap-1.5">
              <Globe className="w-4 h-4 text-indigo-600" />
              Your Live Public Application URL
            </span>
            <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
              HTTPS Live Active
            </span>
          </div>
          <div className="flex items-center gap-2">
            <input
              type="text"
              readOnly
              value={publicUrl}
              className="w-full bg-white border border-indigo-200 rounded-xl px-3 py-2 text-xs font-mono text-slate-800 font-semibold selection:bg-indigo-100 outline-none"
            />
            <button
              onClick={handleCopyUrl}
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 cursor-pointer shadow-xs"
            >
              {copiedUrl ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              {copiedUrl ? 'Copied' : 'Copy'}
            </button>
          </div>
          <p className="text-[11px] text-indigo-700">
            This is the permanent public URL that powers your Android App via Trusted Web Activity (TWA).
          </p>
        </div>

        {/* PWA & Play Store Pre-Flight Checklist */}
        <div className="border border-slate-200 rounded-2xl p-4 space-y-3 bg-slate-50/50">
          <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            Play Store Compliance Audit
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
            <div className="flex items-center gap-2 bg-white p-2.5 rounded-xl border border-slate-200">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <div>
                <div className="font-bold text-slate-800">Web App Manifest</div>
                <div className="text-[10px] text-slate-500 font-mono">/manifest.json (Standalone)</div>
              </div>
            </div>

            <div className="flex items-center gap-2 bg-white p-2.5 rounded-xl border border-slate-200">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <div>
                <div className="font-bold text-slate-800">Service Worker</div>
                <div className="text-[10px] text-slate-500 font-mono">/sw.js (Offline precache)</div>
              </div>
            </div>

            <div className="flex items-center gap-2 bg-white p-2.5 rounded-xl border border-slate-200">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <div>
                <div className="font-bold text-slate-800">High-Res & Maskable Icons</div>
                <div className="text-[10px] text-slate-500 font-mono">192x192 & 512x512 PNG</div>
              </div>
            </div>

            <div className="flex items-center gap-2 bg-white p-2.5 rounded-xl border border-slate-200">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <div>
                <div className="font-bold text-slate-800">Digital Asset Links</div>
                <div className="text-[10px] text-slate-500 font-mono">/.well-known/assetlinks.json</div>
              </div>
            </div>
          </div>
        </div>

        {/* 1-Click Package on PWABuilder */}
        <div className="p-5 bg-gradient-to-br from-indigo-900 to-slate-900 rounded-2xl text-white space-y-3 shadow-lg">
          <div className="flex items-start justify-between">
            <div>
              <span className="text-[10px] font-mono uppercase tracking-widest text-indigo-300 font-bold block mb-1">
                Official Google & Microsoft Partner Tool
              </span>
              <h4 className="text-base font-bold flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-400" />
                Generate Android App Bundle (.aab) with PWABuilder
              </h4>
              <p className="text-xs text-slate-300 mt-1 max-w-lg">
                PWABuilder instantly compiles this live URL into a signed or unsigned Android App Bundle (<code>.aab</code>) and APK that you can upload directly to Google Play Console.
              </p>
            </div>
          </div>

          <div className="pt-2 flex flex-wrap gap-2">
            <a
              href={pwaBuilderUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs px-4 py-2.5 rounded-xl transition-all shadow-md cursor-pointer"
            >
              <Download className="w-4 h-4" />
              Generate .AAB on PWABuilder
              <ExternalLink className="w-3.5 h-3.5 ml-1" />
            </a>

            <button
              onClick={handleCopyUrl}
              className="inline-flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs px-3 py-2.5 rounded-xl border border-slate-700 transition-colors cursor-pointer"
            >
              <Copy className="w-3.5 h-3.5" />
              Copy URL for Bubblewrap CLI
            </button>
          </div>
        </div>

        {/* Step-by-Step Google Play Console Guide */}
        <div className="space-y-3 text-xs">
          <h4 className="font-bold text-slate-900 text-sm">
            How to Upload to Google Play Store (4 Simple Steps):
          </h4>

          <ol className="space-y-2.5 text-slate-700">
            <li className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-50 border border-slate-200">
              <span className="w-5 h-5 rounded-full bg-indigo-600 text-white font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">
                1
              </span>
              <div>
                <strong className="text-slate-900 block">Download the .AAB from PWABuilder:</strong>
                Click the green button above, click <em>"Package for Android"</em>, select <em>"Google Play Store"</em>, and download your <code>.aab</code> file.
              </div>
            </li>

            <li className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-50 border border-slate-200">
              <span className="w-5 h-5 rounded-full bg-indigo-600 text-white font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">
                2
              </span>
              <div>
                <strong className="text-slate-900 block">Open Google Play Console:</strong>
                Go to <a href="https://play.google.com/console" target="_blank" rel="noreferrer" className="text-indigo-600 underline font-semibold">play.google.com/console</a> and click <strong>Create app</strong>. Set the name as <em>Meri Inventory</em>.
              </div>
            </li>

            <li className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-50 border border-slate-200">
              <span className="w-5 h-5 rounded-full bg-indigo-600 text-white font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">
                3
              </span>
              <div>
                <strong className="text-slate-900 block">Upload the .AAB Package:</strong>
                Under <strong>Release &gt; Production</strong> (or Testing), click <strong>Create new release</strong> and drag & drop the downloaded <code>.aab</code> bundle file.
              </div>
            </li>

            <li className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-50 border border-slate-200">
              <span className="w-5 h-5 rounded-full bg-indigo-600 text-white font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">
                4
              </span>
              <div>
                <strong className="text-slate-900 block">Link App Signing Key (Removes Browser Bar):</strong>
                Copy your <strong>SHA-256 certificate fingerprint</strong> from Play Console (under <em>Setup &gt; App Integrity</em>) and paste it into the field below to verify ownership.
              </div>
            </li>
          </ol>
        </div>

        {/* SHA-256 AssetLinks Form */}
        <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-2">
          <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
            <Key className="w-3.5 h-3.5 text-indigo-600" />
            Add Google Play Console SHA-256 Fingerprint
          </label>
          <form onSubmit={handleUpdateSha} className="flex gap-2">
            <input
              type="text"
              value={shaInput}
              onChange={(e) => setShaInput(e.target.value)}
              placeholder="e.g. 14:6D:E9:7D:0F:52:AB:E0:EC:4E:91:27..."
              className="flex-1 bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono uppercase text-slate-900 focus:ring-2 focus:ring-indigo-500 outline-none"
            />
            <button
              type="submit"
              disabled={isUpdatingSha || !shaInput.trim()}
              className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold px-4 py-2 rounded-xl transition-all cursor-pointer shadow-xs disabled:opacity-50"
            >
              {isUpdatingSha ? 'Saving...' : 'Save SHA-256'}
            </button>
          </form>
          {shaSuccessMsg && (
            <p className="text-xs text-emerald-700 font-semibold flex items-center gap-1 mt-1">
              <Check className="w-3.5 h-3.5" />
              {shaSuccessMsg}
            </p>
          )}
        </div>

        <div className="pt-2 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold cursor-pointer transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
