import React, { useState, useEffect } from 'react';
import { InvoiceRecord, Salesperson } from '../types';
import {
  Search,
  Receipt,
  User,
  Phone,
  Calendar,
  CreditCard,
  Printer,
  Share2,
  ExternalLink,
  Tag,
  Clock,
  Filter,
  RefreshCw,
  ShoppingBag,
  Building2,
} from 'lucide-react';

interface BillsHistoryModuleProps {
  salespersons: Salesperson[];
  onViewInvoice: (invoice: InvoiceRecord) => void;
}

export const BillsHistoryModule: React.FC<BillsHistoryModuleProps> = ({
  salespersons,
  onViewInvoice,
}) => {
  const [invoices, setInvoices] = useState<InvoiceRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSalesperson, setSelectedSalesperson] = useState<string>('ALL');
  const [selectedPaymentMode, setSelectedPaymentMode] = useState<string>('ALL');
  const [whatsappCopied, setWhatsappCopied] = useState<string | null>(null);

  // Fetch invoices from backend
  const fetchInvoices = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/invoices');
      const data = await res.json();
      if (data.success && Array.isArray(data.invoices)) {
        setInvoices(data.invoices);
      }
    } catch (err) {
      console.error('Failed to fetch invoices:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchInvoices();
  }, []);

  // Multi-field search across: Bill No, Customer Name, Mobile Number, Salesperson Name, Item Name / IMEI
  const filteredInvoices = invoices.filter((inv) => {
    const q = searchTerm.toLowerCase().trim();
    const matchesQuery =
      !q ||
      inv.invoiceNo.toLowerCase().includes(q) ||
      inv.billTo.customerName.toLowerCase().includes(q) ||
      inv.billTo.mobile.replace(/\D/g, '').includes(q.replace(/\D/g, '')) ||
      inv.salesperson.toLowerCase().includes(q) ||
      inv.items.some(
        (it) =>
          it.particulars.toLowerCase().includes(q) ||
          (it.imei && it.imei.toLowerCase().includes(q))
      );

    const matchesSalesperson =
      selectedSalesperson === 'ALL' ||
      inv.salesperson.toLowerCase() === selectedSalesperson.toLowerCase();

    const matchesPaymentMode =
      selectedPaymentMode === 'ALL' || inv.paymentMode === selectedPaymentMode;

    return matchesQuery && matchesSalesperson && matchesPaymentMode;
  });

  // Calculate stats
  const totalBilled = filteredInvoices.reduce((sum, inv) => sum + inv.netTotal, 0);
  const totalTax = filteredInvoices.reduce((sum, inv) => sum + inv.totalTax, 0);

  // Generate WhatsApp Message & open WhatsApp web
  const handleShareWhatsApp = (inv: InvoiceRecord) => {
    const cleanPhone = inv.billTo.mobile.replace(/\D/g, '');
    const phoneWithCountry = cleanPhone.length === 10 ? `91${cleanPhone}` : cleanPhone;
    const itemsSummary = inv.items
      .map((it) => `• ${it.particulars} (IMEI: ${it.imei}) - ₹${it.amount.toLocaleString('en-IN')}`)
      .join('\n');

    const msg = encodeURIComponent(
      `🧾 *TAX INVOICE - ${inv.storeDetails.name}*\n` +
        `----------------------------------------\n` +
        `*Invoice No:* ${inv.invoiceNo}\n` +
        `*Date:* ${inv.invoiceDate} ${inv.invoiceTime}\n` +
        `*Salesperson:* ${inv.salesperson}\n` +
        `*Customer:* ${inv.billTo.customerName}\n` +
        `*Payment Mode:* ${inv.paymentMode}${inv.financierDetails ? ` (${inv.financierDetails.financierName})` : ''}\n` +
        `----------------------------------------\n` +
        `*Items Purchased:*\n${itemsSummary}\n` +
        `----------------------------------------\n` +
        `*Total GST:* ₹${inv.totalTax.toLocaleString('en-IN')}\n` +
        `*Net Total:* ₹${inv.netTotal.toLocaleString('en-IN')}\n\n` +
        `Thank you for shopping with ${inv.storeDetails.name}!\nVisit again.`
    );

    window.open(`https://wa.me/${phoneWithCountry}?text=${msg}`, '_blank');
    setWhatsappCopied(inv.id);
    setTimeout(() => setWhatsappCopied(null), 2500);
  };

  return (
    <div className="space-y-6">
      {/* Top Stat Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
            Total Invoices
          </span>
          <div className="text-2xl font-black text-slate-900 mt-1 font-mono">
            {filteredInvoices.length}
          </div>
          <span className="text-xs text-slate-400">Bills Generated</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
            Gross Billing
          </span>
          <div className="text-2xl font-black text-indigo-600 mt-1 font-mono">
            ₹{totalBilled.toLocaleString('en-IN')}
          </div>
          <span className="text-xs text-slate-400">Inclusive of Taxes</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
            GST Collected
          </span>
          <div className="text-2xl font-black text-emerald-600 mt-1 font-mono">
            ₹{totalTax.toLocaleString('en-IN')}
          </div>
          <span className="text-xs text-slate-400">CGST + SGST / IGST</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
              Active Staff
            </span>
            <div className="text-2xl font-black text-slate-900 mt-1">
              {salespersons.length}
            </div>
            <span className="text-xs text-slate-400">Salespersons Configured</span>
          </div>
          <button
            onClick={fetchInvoices}
            className="p-2.5 bg-slate-100 hover:bg-slate-200 rounded-xl text-slate-600 transition-colors cursor-pointer"
            title="Refresh Invoices"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Multi-Criteria Search & Filter Header */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Receipt className="w-5 h-5 text-indigo-600" />
              Search & View Old Bills
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Find historical invoices instantly by bill number, customer name, mobile number, or salesperson.
            </p>
          </div>
        </div>

        {/* Search bar */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          <div className="md:col-span-6 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by Bill No (e.g. INV-2026-0001), Customer, Mobile (+91), or Salesperson..."
              className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium text-slate-900 focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute right-3 top-2.5 text-xs text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                Clear
              </button>
            )}
          </div>

          {/* Filter by Salesperson */}
          <div className="md:col-span-3">
            <div className="relative">
              <User className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
              <select
                value={selectedSalesperson}
                onChange={(e) => setSelectedSalesperson(e.target.value)}
                className="w-full pl-8 pr-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium text-slate-800 focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none"
              >
                <option value="ALL">All Salespersons</option>
                {salespersons.map((sp) => (
                  <option key={sp.id} value={sp.name}>
                    {sp.name} {sp.code ? `(${sp.code})` : ''}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Filter by Payment Mode */}
          <div className="md:col-span-3">
            <div className="relative">
              <CreditCard className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
              <select
                value={selectedPaymentMode}
                onChange={(e) => setSelectedPaymentMode(e.target.value)}
                className="w-full pl-8 pr-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium text-slate-800 focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none"
              >
                <option value="ALL">All Payment Modes</option>
                <option value="Cash">Cash</option>
                <option value="UPI">UPI</option>
                <option value="Card">Card</option>
                <option value="Finance">Finance / Loan</option>
              </select>
            </div>
          </div>
        </div>

        {/* Quick Search Tag Suggestions */}
        <div className="flex flex-wrap items-center gap-1.5 pt-1 text-xs text-slate-500">
          <span className="font-semibold text-slate-600">Quick Filters:</span>
          {salespersons.slice(0, 3).map((sp) => (
            <button
              key={sp.id}
              onClick={() => {
                setSelectedSalesperson(sp.name);
                setSearchTerm('');
              }}
              className={`px-2 py-0.5 rounded-lg border text-[11px] cursor-pointer transition-colors ${
                selectedSalesperson === sp.name
                  ? 'bg-indigo-600 text-white border-indigo-600 font-bold'
                  : 'bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-700'
              }`}
            >
              👤 {sp.name}
            </button>
          ))}
          <button
            onClick={() => {
              setSelectedPaymentMode('Finance');
              setSelectedSalesperson('ALL');
            }}
            className={`px-2 py-0.5 rounded-lg border text-[11px] cursor-pointer transition-colors ${
              selectedPaymentMode === 'Finance'
                ? 'bg-amber-600 text-white border-amber-600 font-bold'
                : 'bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-700'
            }`}
          >
            🏦 Financed Sales
          </button>
          {(selectedSalesperson !== 'ALL' || selectedPaymentMode !== 'ALL' || searchTerm) && (
            <button
              onClick={() => {
                setSelectedSalesperson('ALL');
                setSelectedPaymentMode('ALL');
                setSearchTerm('');
              }}
              className="text-xs text-indigo-600 hover:underline font-bold ml-2 cursor-pointer"
            >
              Reset Filters
            </button>
          )}
        </div>
      </div>

      {/* Invoices List / Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 font-bold uppercase tracking-wider text-[10px]">
              <tr>
                <th className="py-3 px-4">Invoice # & Date</th>
                <th className="py-3 px-4">Customer Details</th>
                <th className="py-3 px-4">Salesperson</th>
                <th className="py-3 px-4">Items & Serial/IMEI</th>
                <th className="py-3 px-4">Payment Mode</th>
                <th className="py-3 px-4 text-right">Amount</th>
                <th className="py-3 px-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredInvoices.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-12 px-4">
                    <div className="max-w-md mx-auto space-y-3">
                      <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto">
                        <Receipt className="w-6 h-6" />
                      </div>
                      <h4 className="text-sm font-bold text-slate-900">
                        {invoices.length === 0
                          ? 'No Invoices Generated Yet'
                          : 'No Invoices Matching Your Search'}
                      </h4>
                      <p className="text-xs text-slate-500">
                        {invoices.length === 0
                          ? 'Complete your first sale in the Stock OUT (POS) tab to issue a Tax Invoice.'
                          : 'Try searching with a different mobile number, customer name, bill number, or salesperson.'}
                      </p>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredInvoices.map((inv) => (
                  <tr key={inv.id} className="hover:bg-slate-50/80 transition-colors">
                    {/* Invoice No & Date */}
                    <td className="py-3.5 px-4">
                      <div className="font-mono font-bold text-indigo-900 text-xs">
                        {inv.invoiceNo}
                      </div>
                      <div className="text-slate-500 text-[11px] flex items-center gap-1 mt-0.5">
                        <Calendar className="w-3 h-3 text-slate-400" />
                        {inv.invoiceDate}
                        <span className="text-slate-300">•</span>
                        <Clock className="w-3 h-3 text-slate-400" />
                        {inv.invoiceTime}
                      </div>
                    </td>

                    {/* Customer */}
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900 text-xs flex items-center gap-1.5">
                        <User className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span>{inv.billTo.customerName || 'Cash Customer'}</span>
                      </div>
                      <div className="text-slate-500 text-[11px] font-mono flex items-center gap-1 mt-0.5">
                        <Phone className="w-3 h-3 text-slate-400 shrink-0" />
                        +91 {inv.billTo.mobile}
                      </div>
                    </td>

                    {/* Salesperson */}
                    <td className="py-3.5 px-4">
                      <span className="inline-flex items-center gap-1 bg-slate-100 text-slate-800 text-[11px] font-semibold px-2 py-1 rounded-lg border border-slate-200">
                        <User className="w-3 h-3 text-indigo-500" />
                        {inv.salesperson || 'Direct'}
                      </span>
                    </td>

                    {/* Items & IMEIs */}
                    <td className="py-3.5 px-4 max-w-xs">
                      <div className="space-y-1">
                        {inv.items.map((it, idx) => (
                          <div key={idx} className="text-[11px]">
                            <span className="font-medium text-slate-900">{it.particulars}</span>
                            <span className="text-[10px] text-slate-500 font-mono block">
                              IMEI: {it.imei}
                            </span>
                          </div>
                        ))}
                      </div>
                    </td>

                    {/* Payment Mode */}
                    <td className="py-3.5 px-4">
                      <span
                        className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          inv.paymentMode === 'Finance'
                            ? 'bg-amber-100 text-amber-800 border border-amber-200'
                            : inv.paymentMode === 'UPI'
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                            : inv.paymentMode === 'Card'
                            ? 'bg-blue-100 text-blue-800 border border-blue-200'
                            : 'bg-slate-100 text-slate-800 border border-slate-200'
                        }`}
                      >
                        {inv.paymentMode}
                      </span>
                      {inv.financierDetails && (
                        <div className="text-[10px] text-amber-900 font-medium mt-1 truncate max-w-[130px]" title={inv.financierDetails.financierName}>
                          {inv.financierDetails.financierName}
                        </div>
                      )}
                    </td>

                    {/* Net Total */}
                    <td className="py-3.5 px-4 text-right">
                      <div className="font-black text-slate-900 text-sm font-mono">
                        ₹{inv.netTotal.toLocaleString('en-IN')}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        Tax: ₹{inv.totalTax.toLocaleString('en-IN')}
                      </div>
                    </td>

                    {/* Actions */}
                    <td className="py-3.5 px-4 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => onViewInvoice(inv)}
                          className="inline-flex items-center gap-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs px-2.5 py-1.5 rounded-lg border border-indigo-200 transition-colors cursor-pointer"
                          title="View & Print Full A4 Invoice"
                        >
                          <Printer className="w-3.5 h-3.5" />
                          View
                        </button>
                        <button
                          onClick={() => handleShareWhatsApp(inv)}
                          className="inline-flex items-center gap-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold text-xs px-2 py-1.5 rounded-lg border border-emerald-200 transition-colors cursor-pointer"
                          title="Share Tax Invoice via WhatsApp"
                        >
                          <Share2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
