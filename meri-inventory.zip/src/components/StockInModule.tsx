import React, { useState, useRef } from 'react';
import {
  UploadCloud,
  Camera,
  CheckCircle2,
  AlertCircle,
  Plus,
  Trash2,
  Sparkles,
  ArrowRight,
  RefreshCw,
  Tag,
  Hash,
  X,
} from 'lucide-react';
import { ExtractedBillData, ExtractedBillItem, InventoryItem } from '../types';
import { playScannerBeep } from '../data/mockBills';

interface StockInModuleProps {
  onStockAdded: (newItems: InventoryItem[]) => void;
}

export const StockInModule: React.FC<StockInModuleProps> = ({ onStockAdded }) => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingStep, setProcessingStep] = useState<string>('');
  const [billData, setBillData] = useState<ExtractedBillData | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  // Process image with Gemini 3.8 Flash OCR
  const processImageWithGemini = async (base64Data: string, mimeType: string = 'image/jpeg') => {
    setIsProcessing(true);
    setErrorMsg(null);
    setSuccessMsg(null);
    setProcessingStep('Sending bill image to Gemini 3.8 Flash Vision OCR...');

    try {
      setProcessingStep('Extracting vendor, line items, and reading 15-digit IMEIs...');
      const response = await fetch('/api/ocr/extract-purchase-bill', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: base64Data,
          mimeType,
        }),
      });

      const result = await response.json();
      if (!result.success || !result.data) {
        throw new Error(result.error || 'Failed to extract bill contents');
      }

      setProcessingStep('Structuring inventory records and validating IMEI lists...');
      setBillData({
        supplierName: result.data.supplierName || 'Distributor Direct',
        supplierBillNo: result.data.supplierBillNo || `PB-${Date.now().toString().slice(-6)}`,
        billDate: result.data.billDate || new Date().toISOString().split('T')[0],
        items: (result.data.items || []).map((it: any) => ({
          brand: it.brand || '',
          model: it.model || '',
          specs: it.specs || '128GB',
          color: it.color || 'Standard',
          hsn: it.hsn || '85171300',
          qty: it.qty || (it.imeiList ? it.imeiList.length : 1),
          purchaseRate: Number(it.purchaseRate) || 0,
          gstPercent: Number(it.gstPercent) || 18,
          sellingPrice: Number(it.sellingPrice) || Math.round(Number(it.purchaseRate || 0) * 1.15 * 1.18),
          imeiList: it.imeiList || [],
        })),
      });

      playScannerBeep('success');
      if (result.isQuotaExceeded) {
        setSuccessMsg(result.message || 'AI OCR quota limit reached. Blank consignment created for manual or barcode scanner entry below.');
      } else {
        setSuccessMsg('Distributor bill parsed successfully! Please review and verify below.');
      }
    } catch (err: any) {
      console.error('OCR Error:', err);
      const isQuota = err.message?.includes('resource_exhausted') || err.message?.includes('quota');
      if (isQuota) {
        setErrorMsg('AI OCR quota currently reached on this key. Click "Enter Manually" to onboard stock and scan barcodes directly.');
      } else {
        setErrorMsg(`OCR Extraction failed: ${err.message}. You can enter consignment manually.`);
      }
      playScannerBeep('error');
    } finally {
      setIsProcessing(false);
      setProcessingStep('');
    }
  };

  const handleStartManualBill = () => {
    setErrorMsg(null);
    setBillData({
      supplierName: '',
      supplierBillNo: `INW-${Date.now().toString().slice(-6)}`,
      billDate: new Date().toISOString().split('T')[0],
      items: [
        {
          brand: '',
          model: '',
          specs: '128GB',
          color: '',
          hsn: '85171300',
          qty: 1,
          purchaseRate: 0,
          gstPercent: 18,
          sellingPrice: 0,
          imeiList: [],
        },
      ],
    });
    playScannerBeep('success');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result as string;
      setSelectedImage(base64);
      processImageWithGemini(base64, file.type || 'image/jpeg');
    };
    reader.readAsDataURL(file);
  };



  // Line item modifications
  const handleItemChange = (index: number, field: keyof ExtractedBillItem, value: any) => {
    if (!billData) return;
    const updated = [...billData.items];
    updated[index] = { ...updated[index], [field]: value };
    setBillData({ ...billData, items: updated });
  };

  const handleAddImeiToItem = (itemIdx: number, newImei: string) => {
    if (!billData || !newImei.trim()) return;
    const clean = newImei.trim();
    const updated = [...billData.items];
    if (!updated[itemIdx].imeiList.includes(clean)) {
      updated[itemIdx].imeiList.push(clean);
      updated[itemIdx].qty = updated[itemIdx].imeiList.length;
      setBillData({ ...billData, items: updated });
    }
  };

  const handleRemoveImei = (itemIdx: number, imeiIdx: number) => {
    if (!billData) return;
    const updated = [...billData.items];
    updated[itemIdx].imeiList.splice(imeiIdx, 1);
    updated[itemIdx].qty = updated[itemIdx].imeiList.length;
    setBillData({ ...billData, items: updated });
  };

  const handleAddEmptyItem = () => {
    if (!billData) return;
    const randomImei = '86' + Math.floor(1000000000000 + Math.random() * 9000000000000);
    setBillData({
      ...billData,
      items: [
        ...billData.items,
        {
          brand: 'Samsung',
          model: 'Galaxy A35 5G',
          specs: '8GB / 128GB',
          color: 'Awesome Navy',
          hsn: '85171300',
          qty: 1,
          purchaseRate: 22000,
          gstPercent: 18,
          sellingPrice: 26999,
          imeiList: [randomImei],
        },
      ],
    });
  };

  const handleRemoveItem = (index: number) => {
    if (!billData) return;
    const updated = billData.items.filter((_, idx) => idx !== index);
    setBillData({ ...billData, items: updated });
  };

  // Submit and save units to inventory with AVAILABLE status
  const handleConfirmOnboard = async () => {
    if (!billData || billData.items.length === 0) return;

    // Validate that each item has at least one IMEI
    const emptyImei = billData.items.some((it) => it.imeiList.length === 0);
    if (emptyImei) {
      setErrorMsg('Each item line must have at least one IMEI number. Add IMEI or remove the line.');
      return;
    }

    setIsSubmitting(true);
    setErrorMsg(null);

    try {
      const response = await fetch('/api/inventory/batch-in', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          supplierName: billData.supplierName,
          supplierBillNo: billData.supplierBillNo,
          items: billData.items,
        }),
      });

      const result = await response.json();
      if (!result.success) {
        throw new Error(result.error || 'Failed to onboard stock');
      }

      playScannerBeep('success');
      onStockAdded(result.items);
      setSuccessMsg(
        `Successfully onboarded ${result.countAdded} mobile units into store inventory with status = AVAILABLE!`
      );
      // Reset bill data
      setBillData(null);
      setSelectedImage(null);
    } catch (err: any) {
      console.error('Onboarding Error:', err);
      setErrorMsg(`Failed to onboard stock: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 rounded-2xl p-6 text-white shadow-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 bg-blue-500/20 text-blue-300 border border-blue-400/30 px-3 py-1 rounded-full text-xs font-semibold mb-2">
              <Sparkles className="w-3.5 h-3.5 text-blue-400" />
              Gemini 3.8 Flash Multimodal OCR
            </div>
            <h1 className="text-2xl font-bold tracking-tight">Stock IN: Purchase Invoice & IMEI Onboarding</h1>
            <p className="text-slate-300 text-sm mt-1 max-w-2xl">
              Snap a distributor bill or upload a purchase memo. AI vision automatically detects products, specs,
              taxable rates, and extracts all 15-digit IMEIs for individual unit inventory tracking.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={handleStartManualBill}
              className="flex items-center gap-2 bg-gradient-to-r from-[#0D9488] to-[#0F766E] hover:from-[#14B8A6] hover:to-[#0D9488] text-white px-4 py-2.5 rounded-xl font-bold text-sm transition-all shadow-md cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              Manual Stock IN
            </button>
            <button
              onClick={() => cameraInputRef.current?.click()}
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white px-4 py-2.5 rounded-xl font-semibold text-sm transition-all shadow-md cursor-pointer"
            >
              <Camera className="w-4 h-4" />
              Capture Bill
            </button>
            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 px-4 py-2.5 rounded-xl font-semibold text-sm transition-all cursor-pointer"
            >
              <UploadCloud className="w-4 h-4" />
              Upload PDF / Image
            </button>
          </div>
        </div>

        {/* Hidden inputs */}
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*,application/pdf"
          onChange={handleFileUpload}
          className="hidden"
        />
        <input
          ref={cameraInputRef}
          type="file"
          accept="image/*"
          capture="environment"
          onChange={handleFileUpload}
          className="hidden"
        />
      </div>

      {/* Notifications */}
      {errorMsg && (
        <div className="bg-rose-50 border border-rose-200 text-rose-800 p-4 rounded-xl flex items-center justify-between gap-3 text-sm">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
            <span>{errorMsg}</span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleStartManualBill}
              className="bg-[#0D9488] hover:bg-[#0F766E] text-white font-bold text-xs px-3 py-1.5 rounded-xl transition-all cursor-pointer shadow-xs"
            >
              Enter Manually
            </button>
            <button onClick={() => setErrorMsg(null)} className="text-rose-500 hover:text-rose-800 p-1">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {successMsg && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-xl flex items-center justify-between gap-3 text-sm">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <span className="font-medium">{successMsg}</span>
          </div>
          <button onClick={() => setSuccessMsg(null)} className="text-emerald-500 hover:text-emerald-800">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}



      {/* Processing Loader */}
      {isProcessing && (
        <div className="bg-white rounded-2xl p-10 border border-slate-200 shadow-md text-center max-w-lg mx-auto">
          <div className="w-14 h-14 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <h3 className="text-lg font-bold text-slate-900">Gemini Vision OCR In Progress</h3>
          <p className="text-sm text-indigo-600 font-medium mt-1 animate-pulse">{processingStep}</p>
          <p className="text-xs text-slate-400 mt-3">
            Analyzing invoice layout, resolving product variants, reading serial numbers...
          </p>
        </div>
      )}

      {/* EDITABLE VERIFICATION & ONBOARDING WIZARD */}
      {billData && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-md overflow-hidden">
          {/* Header Bar */}
          <div className="bg-slate-900 text-white p-5 flex flex-wrap items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-xs px-2.5 py-0.5 rounded-full font-bold">
                  OCR Extracted
                </span>
                <span className="text-xs text-slate-400">Step 2: Verify & Edit before Inwarding</span>
              </div>
              <h2 className="text-lg font-bold mt-1">Review Distributor Consignment Details</h2>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => {
                  setBillData(null);
                  setSelectedImage(null);
                }}
                className="text-slate-300 hover:text-white text-xs font-semibold px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 transition-colors cursor-pointer"
              >
                Cancel / Reset
              </button>
              <button
                onClick={handleConfirmOnboard}
                disabled={isSubmitting}
                className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-bold px-5 py-2.5 rounded-xl transition-all shadow-md cursor-pointer disabled:opacity-50"
              >
                {isSubmitting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    Onboarding Units...
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    Confirm & Inward Stock ({billData.items.reduce((s, it) => s + it.imeiList.length, 0)} Units)
                  </>
                )}
              </button>
            </div>
          </div>

          <div className="p-6 space-y-6">
            {/* Distributor Meta Fields */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Distributor / Supplier Name</label>
                <input
                  type="text"
                  value={billData.supplierName}
                  onChange={(e) => setBillData({ ...billData, supplierName: e.target.value })}
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-900 font-medium focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Distributor Invoice / Bill No</label>
                <input
                  type="text"
                  value={billData.supplierBillNo}
                  onChange={(e) => setBillData({ ...billData, supplierBillNo: e.target.value })}
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-900 font-mono font-medium focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Consignment Date</label>
                <input
                  type="date"
                  value={billData.billDate}
                  onChange={(e) => setBillData({ ...billData, billDate: e.target.value })}
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-900 font-medium focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>
            </div>

            {/* Line Items & IMEI Managers */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Extracted Product Lines & Units</h3>
                  <p className="text-xs text-slate-500">
                    Each unit is individually serialized with its unique 15-digit IMEI number.
                  </p>
                </div>
                <button
                  onClick={handleAddEmptyItem}
                  className="flex items-center gap-1.5 text-xs font-bold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Add Another Product
                </button>
              </div>

              {billData.items.map((item, itemIdx) => (
                <div
                  key={itemIdx}
                  className="border border-slate-200 rounded-xl p-4 bg-white shadow-xs hover:border-slate-300 transition-all space-y-4"
                >
                  <div className="grid grid-cols-1 md:grid-cols-6 gap-3 items-end">
                    <div className="md:col-span-1">
                      <label className="text-[11px] font-bold text-slate-600 block mb-1">Brand</label>
                      <input
                        type="text"
                        value={item.brand}
                        onChange={(e) => handleItemChange(itemIdx, 'brand', e.target.value)}
                        className="w-full border border-slate-300 rounded-md px-2.5 py-1.5 text-xs font-semibold focus:ring-2 focus:ring-indigo-500 outline-none"
                      />
                    </div>
                    <div className="md:col-span-2">
                      <label className="text-[11px] font-bold text-slate-600 block mb-1">Model Name</label>
                      <input
                        type="text"
                        value={item.model}
                        onChange={(e) => handleItemChange(itemIdx, 'model', e.target.value)}
                        className="w-full border border-slate-300 rounded-md px-2.5 py-1.5 text-xs font-semibold focus:ring-2 focus:ring-indigo-500 outline-none"
                      />
                    </div>
                    <div className="md:col-span-1">
                      <label className="text-[11px] font-bold text-slate-600 block mb-1">Specs (RAM/ROM)</label>
                      <input
                        type="text"
                        value={item.specs}
                        onChange={(e) => handleItemChange(itemIdx, 'specs', e.target.value)}
                        className="w-full border border-slate-300 rounded-md px-2.5 py-1.5 text-xs focus:ring-2 focus:ring-indigo-500 outline-none"
                      />
                    </div>
                    <div className="md:col-span-1">
                      <label className="text-[11px] font-bold text-slate-600 block mb-1">Color</label>
                      <input
                        type="text"
                        value={item.color}
                        onChange={(e) => handleItemChange(itemIdx, 'color', e.target.value)}
                        className="w-full border border-slate-300 rounded-md px-2.5 py-1.5 text-xs focus:ring-2 focus:ring-indigo-500 outline-none"
                      />
                    </div>
                    <div className="md:col-span-1 flex items-center justify-end">
                      <button
                        onClick={() => handleRemoveItem(itemIdx)}
                        className="text-rose-500 hover:text-rose-700 hover:bg-rose-50 p-1.5 rounded-md transition-colors"
                        title="Remove product"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Financial Values */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3 bg-slate-50/80 p-3 rounded-lg border border-slate-200">
                    <div>
                      <label className="text-[10px] font-bold text-slate-600 block mb-0.5">HSN Code</label>
                      <input
                        type="text"
                        value={item.hsn}
                        onChange={(e) => handleItemChange(itemIdx, 'hsn', e.target.value)}
                        className="w-full border border-slate-300 rounded px-2 py-1 text-xs font-mono"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-bold text-slate-600 block mb-0.5">
                        Purchase Rate (Excl. GST)
                      </label>
                      <div className="relative">
                        <span className="absolute left-2 top-1 text-xs text-slate-400">₹</span>
                        <input
                          type="number"
                          value={item.purchaseRate}
                          onChange={(e) => handleItemChange(itemIdx, 'purchaseRate', Number(e.target.value))}
                          className="w-full border border-slate-300 rounded pl-5 pr-2 py-1 text-xs font-mono font-bold"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="text-[10px] font-bold text-slate-600 block mb-0.5">GST Rate</label>
                      <select
                        value={item.gstPercent}
                        onChange={(e) => handleItemChange(itemIdx, 'gstPercent', Number(e.target.value))}
                        className="w-full border border-slate-300 rounded px-2 py-1 text-xs bg-white"
                      >
                        <option value={18}>18% (Smartphones)</option>
                        <option value={12}>12% (Telecom)</option>
                        <option value={28}>28% (Luxury)</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-[10px] font-bold text-slate-600 block mb-0.5">
                        Selling Price (Incl. GST)
                      </label>
                      <div className="relative">
                        <span className="absolute left-2 top-1 text-xs text-slate-400">₹</span>
                        <input
                          type="number"
                          value={item.sellingPrice}
                          onChange={(e) => handleItemChange(itemIdx, 'sellingPrice', Number(e.target.value))}
                          className="w-full border border-slate-300 rounded pl-5 pr-2 py-1 text-xs font-mono font-bold text-emerald-800"
                        />
                      </div>
                    </div>
                  </div>

                  {/* IMEI Manager for this line */}
                  <div className="space-y-2 pt-1 border-t border-dashed border-slate-200">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-800 flex items-center gap-1">
                          <Hash className="w-3.5 h-3.5 text-indigo-600" />
                          Serial / IMEI Numbers
                        </span>
                        <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800">
                          {item.imeiList.length} Units Found
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-500">Status will be set to: AVAILABLE</span>
                    </div>

                    {/* IMEI Chips */}
                    <div className="flex flex-wrap gap-2">
                      {item.imeiList.map((imei, imeiIdx) => (
                        <div
                          key={imeiIdx}
                          className="inline-flex items-center gap-1.5 bg-slate-100 border border-slate-300 hover:border-slate-400 px-2.5 py-1 rounded-md text-xs font-mono text-slate-800"
                        >
                          <span className="text-slate-400 text-[10px]">#{imeiIdx + 1}</span>
                          <span className="font-semibold">{imei}</span>
                          <button
                            onClick={() => handleRemoveImei(itemIdx, imeiIdx)}
                            className="text-slate-400 hover:text-rose-600 ml-1"
                            title="Remove this IMEI"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      ))}

                      {/* Quick Add IMEI input */}
                      <form
                        onSubmit={(e) => {
                          e.preventDefault();
                          const input = (e.currentTarget.elements.namedItem('newImei') as HTMLInputElement);
                          if (input?.value) {
                            handleAddImeiToItem(itemIdx, input.value);
                            input.value = '';
                          }
                        }}
                        className="inline-flex items-center gap-1"
                      >
                        <input
                          name="newImei"
                          type="text"
                          placeholder="+ Add IMEI manually"
                          className="border border-dashed border-slate-400 rounded-md px-2 py-1 text-xs font-mono w-40 outline-none focus:border-indigo-600"
                        />
                        <button
                          type="submit"
                          className="bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs px-2 py-1 rounded cursor-pointer"
                        >
                          Add
                        </button>
                      </form>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Bottom Finalize Bar */}
            <div className="pt-4 border-t border-slate-200 flex flex-wrap items-center justify-between gap-4">
              <div className="text-xs text-slate-600">
                Total Consignment Stock Value:{' '}
                <strong className="text-slate-900 font-mono text-sm">
                  ₹
                  {billData.items
                    .reduce((sum, it) => sum + it.purchaseRate * it.imeiList.length * (1 + it.gstPercent / 100), 0)
                    .toLocaleString('en-IN', { maximumFractionDigits: 0 })}
                </strong>{' '}
                across{' '}
                <strong className="text-indigo-700">
                  {billData.items.reduce((sum, it) => sum + it.imeiList.length, 0)} units
                </strong>
              </div>

              <button
                onClick={handleConfirmOnboard}
                disabled={isSubmitting}
                className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm px-6 py-2.5 rounded-xl shadow-md cursor-pointer transition-all disabled:opacity-50"
              >
                <CheckCircle2 className="w-4 h-4" />
                Inward to Inventory as AVAILABLE
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
