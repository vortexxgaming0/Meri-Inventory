import React from 'react';
import {
  Smartphone,
  ScanLine,
  Layers,
  Volume2,
  VolumeX,
  Sparkles,
  Receipt,
  Store,
  Monitor,
  Settings,
  LogOut,
  Building2,
} from 'lucide-react';
import { StoreProfile } from '../types';

interface NavbarProps {
  activeTab: 'STOCK_IN' | 'STOCK_OUT' | 'INVENTORY' | 'BILLS_HISTORY' | 'INVOICE_VIEW';
  setActiveTab: (tab: 'STOCK_IN' | 'STOCK_OUT' | 'INVENTORY' | 'BILLS_HISTORY' | 'INVOICE_VIEW') => void;
  availableCount: number;
  soldCount: number;
  isMobileFrame: boolean;
  setIsMobileFrame: (val: boolean | ((prev: boolean) => boolean)) => void;
  soundEnabled: boolean;
  setSoundEnabled: (val: boolean | ((prev: boolean) => boolean)) => void;
  hasActiveInvoice: boolean;
  store: StoreProfile;
  onOpenStoreSettings: () => void;
  onOpenPlayStoreModal: () => void;
  onLogout: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  availableCount,
  soldCount,
  isMobileFrame,
  setIsMobileFrame,
  soundEnabled,
  setSoundEnabled,
  hasActiveInvoice,
  store,
  onOpenStoreSettings,
  onOpenPlayStoreModal,
  onLogout,
}) => {
  return (
    <header className="bg-[#062D2A] border-b border-[#0F4743] text-white sticky top-0 z-40 print:hidden shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Brand Logo & Store Meta */}
          <div className="flex items-center gap-3 max-w-[280px] sm:max-w-md">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#0D9488] to-[#14B8A6] flex items-center justify-center shadow-md shadow-teal-900/30 shrink-0 border border-teal-400/30">
              <Store className="w-5 h-5 text-white" />
            </div>
            <div className="overflow-hidden">
              <div className="flex items-center gap-2">
                <h1 className="font-black text-sm sm:text-base tracking-tight text-white truncate" title={store.name}>
                  {store.name || 'My Store'}
                </h1>
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-teal-500/20 text-teal-200 border border-teal-400/30 font-semibold shrink-0 hidden sm:inline-block">
                  {store.category}
                </span>
              </div>
              <p className="text-[11px] text-teal-200/80 flex items-center gap-1.5 truncate">
                {store.city && (
                  <>
                    <span className="truncate">{store.city}{store.state ? `, ${store.state}` : ''}</span>
                    <span>•</span>
                  </>
                )}
                <span className={store.hasGst && store.gstin ? 'text-teal-300 font-mono' : 'text-amber-300 font-medium'}>
                  {store.hasGst && store.gstin ? `GST: ${store.gstin}` : 'Retail Store'}
                </span>
              </p>
            </div>
          </div>

          {/* Center Navigation Tabs */}
          <nav className="hidden md:flex items-center gap-1 bg-[#093A36] p-1 rounded-xl border border-[#115E59]">
            <button
              onClick={() => setActiveTab('STOCK_IN')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'STOCK_IN'
                  ? 'bg-[#0D9488] text-white shadow-xs'
                  : 'text-teal-100 hover:text-white hover:bg-teal-800/40'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              Stock IN (AI OCR)
            </button>

            <button
              onClick={() => setActiveTab('STOCK_OUT')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'STOCK_OUT'
                  ? 'bg-[#0D9488] text-white shadow-xs'
                  : 'text-teal-100 hover:text-white hover:bg-teal-800/40'
              }`}
            >
              <ScanLine className="w-3.5 h-3.5 text-emerald-300" />
              Stock OUT (POS)
            </button>

            <button
              onClick={() => setActiveTab('INVENTORY')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'INVENTORY'
                  ? 'bg-[#0D9488] text-white shadow-xs'
                  : 'text-teal-100 hover:text-white hover:bg-teal-800/40'
              }`}
            >
              <Layers className="w-3.5 h-3.5 text-teal-300" />
              Inventory ({availableCount})
            </button>

            <button
              onClick={() => setActiveTab('BILLS_HISTORY')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'BILLS_HISTORY'
                  ? 'bg-[#0D9488] text-white shadow-xs'
                  : 'text-teal-100 hover:text-white hover:bg-teal-800/40'
              }`}
            >
              <Receipt className="w-3.5 h-3.5 text-amber-300" />
              Bills & History
            </button>



            {hasActiveInvoice && (
              <button
                onClick={() => setActiveTab('INVOICE_VIEW')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  activeTab === 'INVOICE_VIEW'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-emerald-400 hover:text-emerald-300 hover:bg-slate-700/50'
                }`}
              >
                <Receipt className="w-3.5 h-3.5" />
                Latest Bill
              </button>
            )}
          </nav>

          {/* Right Action Controls */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* View Mode Toggle: Mobile Handheld Simulator vs Desktop POS */}
            {/* Google Play Store Export Button */}
            <button
              onClick={onOpenPlayStoreModal}
              className="flex items-center gap-1.5 text-xs text-white bg-gradient-to-r from-[#E67E22] to-[#D97706] hover:from-[#F97316] hover:to-[#EA580C] px-3 py-1.5 rounded-xl transition-all cursor-pointer shadow-sm font-black"
              title="Generate Google Play Store Build (.AAB / APK)"
            >
              <Smartphone className="w-3.5 h-3.5 text-amber-100" />
              <span className="hidden sm:inline">Play Store (.AAB)</span>
            </button>

            {/* View Mode Toggle: Mobile Handheld Simulator vs Desktop POS */}
            <button
              onClick={() => setIsMobileFrame((prev) => !prev)}
              className="flex items-center gap-1.5 text-xs text-teal-100 hover:text-white bg-[#0B4540] hover:bg-[#0F5A54] border border-[#146B64] px-2.5 py-1.5 rounded-xl transition-colors cursor-pointer"
              title={isMobileFrame ? 'Switch to Full POS Terminal View' : 'Simulate Mobile Handset View'}
            >
              {isMobileFrame ? <Monitor className="w-3.5 h-3.5 text-teal-300" /> : <Smartphone className="w-3.5 h-3.5 text-teal-300" />}
              <span className="hidden lg:inline">{isMobileFrame ? 'POS Screen' : 'Mobile View'}</span>
            </button>

            {/* Store Settings Button */}
            <button
              onClick={onOpenStoreSettings}
              className="text-teal-200 hover:text-white p-2 rounded-xl bg-[#0B4540] hover:bg-[#0F5A54] border border-[#146B64] transition-colors cursor-pointer"
              title="Store Profile & GST Settings"
            >
              <Settings className="w-4 h-4 text-teal-200" />
            </button>

            {/* Sound Toggle */}
            <button
              onClick={() => setSoundEnabled((prev) => !prev)}
              className="text-teal-300 hover:text-white p-2 rounded-xl hover:bg-[#0F5A54] transition-colors cursor-pointer"
              title={soundEnabled ? 'Scanner Beep Enabled' : 'Scanner Beep Muted'}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-300" /> : <VolumeX className="w-4 h-4 text-teal-500" />}
            </button>



            {/* Logout / Switch User */}
            <button
              onClick={onLogout}
              className="text-rose-300 hover:text-rose-100 p-2 rounded-xl hover:bg-rose-500/20 transition-colors cursor-pointer"
              title="Logout / Switch Account"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Mobile Navigation Bar for small screens */}
        <div className="flex md:hidden items-center justify-around py-2 border-t border-[#0F4743] bg-[#062D2A] text-xs">
          <button
            onClick={() => setActiveTab('STOCK_IN')}
            className={`px-2 py-1 rounded-lg font-bold transition-colors ${activeTab === 'STOCK_IN' ? 'text-teal-300 bg-teal-900/40' : 'text-teal-200/70'}`}
          >
            Stock IN
          </button>
          <button
            onClick={() => setActiveTab('STOCK_OUT')}
            className={`px-2 py-1 rounded-lg font-bold transition-colors ${activeTab === 'STOCK_OUT' ? 'text-teal-300 bg-teal-900/40' : 'text-teal-200/70'}`}
          >
            Stock OUT
          </button>
          <button
            onClick={() => setActiveTab('INVENTORY')}
            className={`px-2 py-1 rounded-lg font-bold transition-colors ${activeTab === 'INVENTORY' ? 'text-teal-300 bg-teal-900/40' : 'text-teal-200/70'}`}
          >
            Inventory ({availableCount})
          </button>
          <button
            onClick={() => setActiveTab('BILLS_HISTORY')}
            className={`px-2 py-1 rounded-lg font-bold transition-colors ${activeTab === 'BILLS_HISTORY' ? 'text-teal-300 bg-teal-900/40' : 'text-teal-200/70'}`}
          >
            Bills
          </button>

          {hasActiveInvoice && (
            <button
              onClick={() => setActiveTab('INVOICE_VIEW')}
              className={`px-2 py-1 rounded-lg font-bold transition-colors ${activeTab === 'INVOICE_VIEW' ? 'text-amber-300 bg-amber-900/40' : 'text-amber-400'}`}
            >
              Bill
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
