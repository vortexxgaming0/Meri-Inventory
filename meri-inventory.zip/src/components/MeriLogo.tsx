import React from 'react';

interface MeriLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  animated?: boolean;
  showText?: boolean;
}

export const MeriLogo: React.FC<MeriLogoProps> = ({
  className = '',
  size = 'md',
  animated = false,
  showText = true,
}) => {
  const sizeMap = {
    sm: { box: 'w-10 h-10', text: 'text-sm', sub: 'text-xs' },
    md: { box: 'w-20 h-20', text: 'text-xl', sub: 'text-base' },
    lg: { box: 'w-36 h-36', text: 'text-3xl', sub: 'text-2xl' },
    xl: { box: 'w-48 h-48', text: 'text-4xl', sub: 'text-3xl' },
  };

  const currentSize = sizeMap[size];

  return (
    <div className={`flex flex-col items-center select-none ${className}`}>
      {/* Visual Logo Container matching reference rounded squircle */}
      <div className={`relative ${currentSize.box} flex items-center justify-center`}>
        <svg
          viewBox="0 0 400 400"
          className="w-full h-full drop-shadow-xl overflow-visible"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            {/* Squircle Background Gradient */}
            <linearGradient id="squircleBg" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#EBF8F6" />
              <stop offset="40%" stopColor="#F7FDFD" />
              <stop offset="100%" stopColor="#E2F5F3" />
            </linearGradient>

            {/* Squircle Border Gradient */}
            <linearGradient id="squircleBorder" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#A7F3D0" />
              <stop offset="50%" stopColor="#5EEAD4" />
              <stop offset="100%" stopColor="#2DD4BF" />
            </linearGradient>

            {/* Box Front Face Teal Gradient */}
            <linearGradient id="boxFaceGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#2DD4BF" />
              <stop offset="100%" stopColor="#0D9488" />
            </linearGradient>

            {/* Box Left Side Darker Teal */}
            <linearGradient id="boxSideGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#14B8A6" />
              <stop offset="100%" stopColor="#0F766E" />
            </linearGradient>

            {/* Cardboard Flap Colors */}
            <linearGradient id="flapGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#FDBA74" />
              <stop offset="100%" stopColor="#EA580C" />
            </linearGradient>

            {/* Growth Arrow Gradient */}
            <linearGradient id="arrowGrad" x1="0%" y1="100%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#2DD4BF" />
              <stop offset="100%" stopColor="#0D9488" />
            </linearGradient>

            {/* Parcel Box Brown Gradient */}
            <linearGradient id="parcelGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#FCD34D" />
              <stop offset="100%" stopColor="#D97706" />
            </linearGradient>
          </defs>

          {/* 1. App Icon Rounded Squircle Badge */}
          <rect
            x="20"
            y="20"
            width="360"
            height="360"
            rx="88"
            fill="url(#squircleBg)"
            stroke="url(#squircleBorder)"
            strokeWidth="10"
          />

          {/* 2. Background Sparkles & Chart Bars (floating above box) */}
          <g className={animated ? 'animate-pulse' : ''}>
            {/* Sparkle top left */}
            <path
              d="M130 90 L135 105 L150 110 L135 115 L130 130 L125 115 L110 110 L125 105 Z"
              fill="#2DD4BF"
              opacity="0.9"
            />
            {/* Sparkle top right */}
            <path
              d="M310 110 L313 120 L323 123 L313 126 L310 136 L307 126 L297 123 L307 120 Z"
              fill="#F59E0B"
              opacity="0.9"
            />
            <circle cx="160" cy="80" r="4" fill="#0D9488" />
            <circle cx="280" cy="85" r="5" fill="#F97316" />
            <circle cx="330" cy="155" r="4" fill="#14B8A6" />

            {/* Chart Dots & Upward Data Bars */}
            <rect x="180" y="95" width="8" height="25" rx="4" fill="#99F6E4" />
            <rect x="195" y="85" width="8" height="35" rx="4" fill="#5EEAD4" />
            <rect x="210" y="70" width="8" height="50" rx="4" fill="#2DD4BF" />
            <rect x="225" y="80" width="8" height="40" rx="4" fill="#14B8A6" />
          </g>

          {/* 3. Upward Growth Arrow Rising from Box */}
          <g className={animated ? 'transition-transform duration-700 hover:scale-105' : ''}>
            <path
              d="M205 130 Q240 100 280 80"
              stroke="#2DD4BF"
              strokeWidth="10"
              strokeLinecap="round"
              fill="none"
            />
            {/* Arrow Head */}
            <path
              d="M260 70 L300 75 L285 110 L275 92 Z"
              fill="#0D9488"
              stroke="#042F2E"
              strokeWidth="4"
              strokeLinejoin="round"
            />
          </g>

          {/* 4. Items Inside the Box: Tablet, Parcel Box, Folder, Briefcase */}
          {/* Tablet (back left) */}
          <g transform="rotate(-10 140 130)">
            <rect
              x="110"
              y="90"
              width="65"
              height="95"
              rx="8"
              fill="#0F172A"
              stroke="#042F2E"
              strokeWidth="4"
            />
            <rect x="116" y="98" width="53" height="78" rx="4" fill="#F8FAFC" />
            {/* Tablet Screen UI Bars */}
            <rect x="122" y="106" width="41" height="6" rx="2" fill="#0D9488" />
            <rect x="122" y="116" width="20" height="4" rx="2" fill="#94A3B8" />
            <rect x="122" y="124" width="28" height="4" rx="2" fill="#94A3B8" />
            <rect x="122" y="132" width="16" height="4" rx="2" fill="#F97316" />
            {/* Mini Chart */}
            <rect x="146" y="145" width="4" height="15" rx="1" fill="#2DD4BF" />
            <rect x="153" y="138" width="4" height="22" rx="1" fill="#0D9488" />
            <rect x="160" y="142" width="4" height="18" rx="1" fill="#F59E0B" />
          </g>

          {/* Document Folder (back right) */}
          <path
            d="M245 130 L285 125 L290 170 L250 175 Z"
            fill="#FDBA74"
            stroke="#C2410C"
            strokeWidth="3"
            strokeLinejoin="round"
          />

          {/* Business Briefcase (middle right) */}
          <rect
            x="225"
            y="145"
            width="55"
            height="40"
            rx="6"
            fill="#0D9488"
            stroke="#042F2E"
            strokeWidth="4"
          />
          <path
            d="M242 145 V138 C242 135 245 133 248 133 H257 C260 133 263 135 263 138 V145"
            stroke="#042F2E"
            strokeWidth="4"
            fill="none"
          />
          <circle cx="252" cy="165" r="3" fill="#FCD34D" />

          {/* Parcel Box 1 (Items box with checkmark) */}
          <rect
            x="205"
            y="120"
            width="45"
            height="40"
            rx="4"
            fill="url(#parcelGrad)"
            stroke="#78350F"
            strokeWidth="3"
          />
          <rect x="212" y="128" width="10" height="10" rx="2" fill="#10B981" />
          <path d="M214 133 L217 136 L221 130" stroke="#FFFFFF" strokeWidth="2" strokeLinecap="round" />
          <text x="225" y="136" fontSize="7" fontWeight="bold" fill="#78350F" fontFamily="sans-serif">
            ITENS
          </text>

          {/* Parcel Box 2 in Front (STOCK with Barcode) */}
          <g>
            <rect
              x="165"
              y="145"
              width="60"
              height="50"
              rx="4"
              fill="url(#parcelGrad)"
              stroke="#78350F"
              strokeWidth="4"
            />
            {/* QR/Barcode sticker */}
            <rect x="175" y="160" width="18" height="18" rx="2" fill="#FFFFFF" />
            <path
              d="M178 163 H182 V167 H178 Z M186 163 H190 V167 H186 Z M178 171 H182 V175 H178 Z M186 171 H190 V175 H186 Z"
              fill="#000000"
            />
            <text x="196" y="174" fontSize="8" fontWeight="900" fill="#78350F" fontFamily="sans-serif">
              STOCK
            </text>
          </g>

          {/* 5. The Main Cute Teal Smiling Box */}
          {/* Left Side Face */}
          <polygon
            points="120,230 170,185 170,270 120,305"
            fill="url(#boxSideGrad)"
            stroke="#042F2E"
            strokeWidth="5"
            strokeLinejoin="round"
          />
          {/* Left Flap fold */}
          <polygon
            points="110,180 170,185 155,205 100,195"
            fill="#F97316"
            stroke="#042F2E"
            strokeWidth="4"
            strokeLinejoin="round"
          />

          {/* Front Face of Smiling Box */}
          <polygon
            points="170,185 305,185 305,270 170,270"
            fill="url(#boxFaceGrad)"
            stroke="#042F2E"
            strokeWidth="5"
            strokeLinejoin="round"
          />

          {/* Box Bottom Border Shadow */}
          <line x1="170" y1="270" x2="305" y2="270" stroke="#042F2E" strokeWidth="6" strokeLinecap="round" />

          {/* Front Flap (warm orange/terracotta folded flap) */}
          <polygon
            points="160,180 315,180 295,208 175,208"
            fill="url(#flapGrad)"
            stroke="#042F2E"
            strokeWidth="5"
            strokeLinejoin="round"
          />

          {/* Left Box Detail: mini label / handle */}
          <rect x="128" y="245" width="22" height="12" rx="3" fill="#FFFFFF" opacity="0.85" />
          <rect x="144" y="270" width="10" height="15" rx="2" fill="#F97316" />

          {/* Right Flap (warm folded corner) */}
          <polygon
            points="305,185 345,190 330,215 295,208"
            fill="#EA580C"
            stroke="#042F2E"
            strokeWidth="4"
            strokeLinejoin="round"
          />

          {/* The Cute Smiling Face on Front Panel */}
          {/* Left Eye (blinking / joyful curved eye) */}
          <ellipse cx="215" cy="235" rx="4.5" ry="6" fill="#042F2E" />
          {/* Right Eye */}
          <ellipse cx="265" cy="235" rx="4.5" ry="6" fill="#042F2E" />

          {/* Pink Cheeks */}
          <ellipse cx="202" cy="245" rx="7" ry="4" fill="#F472B6" opacity="0.75" />
          <ellipse cx="278" cy="245" rx="7" ry="4" fill="#F472B6" opacity="0.75" />

          {/* Cute Smile Curve */}
          <path
            d="M228 245 Q240 258 252 245"
            stroke="#042F2E"
            strokeWidth="4.5"
            strokeLinecap="round"
            fill="none"
          />
        </svg>
      </div>

      {/* Typography: "meri" in vibrant orange & "inventory" in deep teal */}
      {showText && (
        <div className="flex flex-col items-center mt-3 text-center leading-none tracking-tight">
          <span
            className={`${currentSize.text} font-black text-[#E67E22] tracking-tight hover:scale-105 transition-transform`}
            style={{ fontFamily: "'Plus Jakarta Sans', system-ui, sans-serif" }}
          >
            meri
          </span>
          <span
            className={`${currentSize.sub} font-black text-[#0D5C58] tracking-tight mt-0.5`}
            style={{ fontFamily: "'Plus Jakarta Sans', system-ui, sans-serif" }}
          >
            inventory
          </span>
        </div>
      )}
    </div>
  );
};
