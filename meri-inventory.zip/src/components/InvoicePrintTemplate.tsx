import React, { useEffect, useRef, useState } from 'react';
import { InvoiceRecord } from '../types';
import QRCode from 'qrcode';
import { Printer, Share2, Download, Check, ArrowLeft, ExternalLink } from 'lucide-react';

interface InvoicePrintTemplateProps {
  invoice: InvoiceRecord;
  onBack?: () => void;
}

export const InvoicePrintTemplate: React.FC<InvoicePrintTemplateProps> = ({ invoice, onBack }) => {
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string>('');
  const [copiedLink, setCopiedLink] = useState(false);
  const printRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Generate valid GST e-Invoice standard QR payload
    const qrPayload = JSON.stringify({
      GSTIN: invoice.storeDetails.gstin,
      DocNo: invoice.invoiceNo,
      DocDt: invoice.invoiceDate,
      TotInvVal: invoice.netTotal,
      ItemCnt: invoice.items.length,
      MainHsnCode: invoice.items[0]?.hsn || '85171300',
      Irn: invoice.uid,
    });

    QRCode.toDataURL(qrPayload, {
      width: 140,
      margin: 1,
      color: {
        dark: '#000000',
        light: '#ffffff',
      },
    })
      .then((url) => setQrCodeDataUrl(url))
      .catch((err) => console.error('Error generating QR:', err));
  }, [invoice]);

  const handlePrint = () => {
    window.print();
  };

  const handleShareWhatsApp = () => {
    const phone = invoice.billTo.mobile.replace(/\D/g, '');
    const itemListText = invoice.items
      .map((it) => `• ${it.particulars.replace('\n', ' - ')}: ₹${(it.rate * (1 + it.gstPercent / 100)).toLocaleString('en-IN')}`)
      .join('%0A');

    const message = `*TAX INVOICE - ${invoice.storeDetails.name}*%0A` +
      `--------------------------------%0A` +
      `*Invoice No:* ${invoice.invoiceNo}%0A` +
      `*Date:* ${invoice.invoiceDate} ${invoice.invoiceTime}%0A` +
      `*Customer:* ${invoice.billTo.customerName}%0A` +
      `*Place of Supply:* ${invoice.placeOfSupply}%0A` +
      `--------------------------------%0A` +
      `*Purchased Items:*%0A${itemListText}%0A` +
      `--------------------------------%0A` +
      `*Payment Mode:* ${invoice.paymentMode}${invoice.financierDetails ? ` (${invoice.financierDetails.financierName} - ${invoice.financierDetails.approvalNo})` : ''}%0A` +
      `*Total Amount Paid:* ₹${invoice.netTotal.toLocaleString('en-IN')}%0A` +
      `--------------------------------%0A` +
      `Thank you for shopping with us! For service & warranty, keep this digital bill copy safe.`;

    const targetUrl = phone ? `https://wa.me/91${phone}?text=${message}` : `https://wa.me/?text=${message}`;
    window.open(targetUrl, '_blank');
  };

  const handleCopyBillDetails = () => {
    const text = `Invoice #${invoice.invoiceNo} | ${invoice.billTo.customerName} | ₹${invoice.netTotal} | ${invoice.invoiceDate}`;
    navigator.clipboard.writeText(text);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <div className="min-h-screen bg-slate-100 py-6 px-4 print:p-0 print:bg-white text-slate-900 font-sans">
      {/* Top Floating Control Bar (Hidden during Print) */}
      <div className="max-w-4xl mx-auto mb-6 flex flex-wrap items-center justify-between gap-3 bg-white p-4 rounded-xl shadow-sm border border-slate-200 print:hidden">
        <div className="flex items-center gap-3">
          {onBack && (
            <button
              onClick={onBack}
              className="flex items-center gap-1.5 text-sm font-semibold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 px-3 py-2 rounded-lg transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to POS
            </button>
          )}
          <div>
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              Invoice #{invoice.invoiceNo}
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                Tax Invoice Verified
              </span>
            </h2>
            <p className="text-xs text-slate-500">
              {invoice.billTo.customerName} • ₹{invoice.netTotal.toLocaleString('en-IN')} • {invoice.paymentMode}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleShareWhatsApp}
            className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold px-3 py-2 rounded-lg transition-colors cursor-pointer shadow-xs"
            title="Send PDF and details to customer WhatsApp"
          >
            <Share2 className="w-3.5 h-3.5" />
            WhatsApp Bill
          </button>

          <button
            onClick={handleCopyBillDetails}
            className="flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold px-3 py-2 rounded-lg transition-colors cursor-pointer"
          >
            {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <ExternalLink className="w-3.5 h-3.5" />}
            {copiedLink ? 'Copied' : 'Copy Summary'}
          </button>

          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold px-4 py-2 rounded-lg transition-colors cursor-pointer shadow-sm"
          >
            <Printer className="w-3.5 h-3.5" />
            Print / PDF (A4)
          </button>
        </div>
      </div>

      {/* =========================================================================
          EXACT A4 TAX INVOICE MATCHING RETAIL SPECIFICATION
          ========================================================================= */}
      <div
        ref={printRef}
        className="max-w-[800px] mx-auto bg-white border border-slate-300 shadow-lg p-7 print:shadow-none print:border-none print:p-4 print:max-w-none text-[11px] leading-tight text-slate-900"
        style={{ fontFamily: "'Plus Jakarta Sans', Arial, sans-serif" }}
      >
        {/* 1. Header Centered Store Details */}
        <div className="text-center pb-3 border-b-2 border-slate-900">
          <h1 className="text-lg font-black tracking-wide uppercase text-slate-900 mb-1">
            {invoice.storeDetails.name}
          </h1>
          <p className="text-[11px] text-slate-700 font-medium">
            {invoice.storeDetails.shopNo}, {invoice.storeDetails.address}
          </p>
          <p className="text-[10px] text-slate-600 mt-0.5">
            Phone: {invoice.storeDetails.phones.join(', ')} | Email: {invoice.storeDetails.email}
          </p>
          <div className="flex flex-wrap justify-center items-center gap-x-4 gap-y-0.5 text-[10px] font-semibold text-slate-800 mt-1">
            <span>GSTIN: <strong className="font-mono text-slate-950">{invoice.storeDetails.gstin}</strong></span>
            <span>PAN: <strong className="font-mono text-slate-950">{invoice.storeDetails.pan}</strong></span>
            <span>State: <strong className="text-slate-950">{invoice.storeDetails.state} (Code: {invoice.storeDetails.stateCode})</strong></span>
            <span>CIN: <strong className="font-mono text-slate-950">{invoice.storeDetails.cin}</strong></span>
          </div>
        </div>

        {/* 2. Title Section */}
        <div className="flex justify-between items-center py-2 px-1 border-b border-slate-800 bg-slate-50 print:bg-transparent">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-900">
            TAX INVOICE
          </span>
          <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 border border-slate-800 rounded-xs text-slate-900 tracking-wider">
            ORIGINAL FOR RECIPIENT
          </span>
        </div>

        {/* 3. 2-Column Meta Section */}
        <div className="grid grid-cols-2 border-b border-slate-400 text-[10px]">
          {/* Left Column */}
          <div className="p-2 border-r border-slate-400 space-y-1">
            <div className="flex">
              <span className="w-24 font-bold text-slate-700">Invoice No:</span>
              <span className="font-mono font-bold text-slate-950 text-[11px]">{invoice.invoiceNo}</span>
            </div>
            <div className="flex">
              <span className="w-24 font-bold text-slate-700">Invoice Time:</span>
              <span className="font-mono text-slate-900">{invoice.invoiceTime}</span>
            </div>
            <div className="pt-1 border-t border-dashed border-slate-300">
              <span className="font-bold text-slate-900 uppercase block mb-0.5 underline">Bill To:</span>
              <div className="font-bold text-slate-950 text-[11px]">{invoice.billTo.customerName}</div>
              <div className="text-slate-700">{invoice.billTo.address}</div>
              <div>Phone: <strong className="font-mono">{invoice.billTo.mobile}</strong></div>
              <div>Place of Supply: <strong>{invoice.placeOfSupply}</strong></div>
              {invoice.billTo.gstin && (
                <div>Customer GSTIN: <strong className="font-mono">{invoice.billTo.gstin}</strong></div>
              )}
            </div>
          </div>

          {/* Right Column */}
          <div className="p-2 space-y-1">
            <div className="flex">
              <span className="w-24 font-bold text-slate-700">Invoice Date:</span>
              <span className="font-mono font-bold text-slate-950 text-[11px]">{invoice.invoiceDate}</span>
            </div>
            <div className="flex">
              <span className="w-24 font-bold text-slate-700">Salesperson:</span>
              <span className="text-slate-900 font-semibold">{invoice.salesperson} ({invoice.salespersonId})</span>
            </div>
            <div className="pt-1 border-t border-dashed border-slate-300">
              <span className="font-bold text-slate-900 uppercase block mb-0.5 underline">Ship To:</span>
              <div className="font-bold text-slate-950 text-[11px]">{invoice.shipTo.name}</div>
              <div className="text-slate-700">{invoice.shipTo.address}</div>
              <div>State: <strong>{invoice.shipTo.state} ({invoice.shipTo.stateCode})</strong></div>
              <div>Reverse Charge: <strong>NO</strong></div>
            </div>
          </div>
        </div>

        {/* 4. Items Table */}
        <div className="overflow-x-auto my-2">
          <table className="w-full border-collapse border border-slate-900 text-[10px]">
            <thead>
              <tr className="bg-slate-100 print:bg-slate-50 text-slate-900 border-b border-slate-900 font-bold">
                <th className="border border-slate-800 p-1 text-center w-7">SNo</th>
                <th className="border border-slate-800 p-1 text-center w-14">Code</th>
                <th className="border border-slate-800 p-1 text-center w-16">I.I/M Code</th>
                <th className="border border-slate-800 p-1 text-left">Particulars (Item name, RAM/Storage, Color, IMEI No)</th>
                <th className="border border-slate-800 p-1 text-center w-16">HSN/SAC</th>
                <th className="border border-slate-800 p-1 text-center w-8">Qty</th>
                <th className="border border-slate-800 p-1 text-right w-16">Rate (₹)</th>
                <th className="border border-slate-800 p-1 text-center w-10">GST %</th>
                <th className="border border-slate-800 p-1 text-right w-18">Amount (₹)</th>
              </tr>
            </thead>
            <tbody>
              {invoice.items.map((item, idx) => (
                <tr key={idx} className="border-b border-slate-300">
                  <td className="border border-slate-800 p-1 text-center font-mono">{item.sNo}</td>
                  <td className="border border-slate-800 p-1 text-center font-mono">{item.code}</td>
                  <td className="border border-slate-800 p-1 text-center font-mono">{item.itemCode}</td>
                  <td className="border border-slate-800 p-1">
                    <div className="font-bold text-slate-950 whitespace-pre-line leading-normal">
                      {item.particulars.split('\n')[0]}
                    </div>
                    {item.particulars.split('\n')[1] && (
                      <div className="font-mono text-[9px] text-slate-800 font-semibold mt-0.5 tracking-tight bg-slate-50 px-1 py-0.5 border border-slate-200 inline-block rounded-xs">
                        {item.particulars.split('\n')[1]}
                      </div>
                    )}
                  </td>
                  <td className="border border-slate-800 p-1 text-center font-mono font-medium">{item.hsn}</td>
                  <td className="border border-slate-800 p-1 text-center font-bold font-mono">{item.qty}</td>
                  <td className="border border-slate-800 p-1 text-right font-mono">{item.rate.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                  <td className="border border-slate-800 p-1 text-center font-mono">{item.gstPercent}%</td>
                  <td className="border border-slate-800 p-1 text-right font-mono font-bold">{item.amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="bg-slate-50 print:bg-transparent font-bold border-t-2 border-slate-900">
                <td colSpan={5} className="border border-slate-800 p-1 text-right pr-2">Total Taxable Value:</td>
                <td className="border border-slate-800 p-1 text-center font-mono">
                  {invoice.items.reduce((sum, it) => sum + it.qty, 0)}
                </td>
                <td className="border border-slate-800 p-1"></td>
                <td className="border border-slate-800 p-1"></td>
                <td className="border border-slate-800 p-1 text-right font-mono text-slate-950 font-black">
                  ₹{invoice.subTotalTaxable.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>

        {/* 5. Tax Summary Table & Amount in Words */}
        <div className="grid grid-cols-12 gap-2 my-2 items-start text-[10px]">
          {/* Left Column: Amount in words & Payment Details */}
          <div className="col-span-6 space-y-1.5 border border-slate-400 p-2 rounded-xs">
            <div>
              <span className="font-bold text-slate-700 block">Total Amount in Words:</span>
              <span className="font-bold text-slate-950 italic text-[11px] block">{invoice.amountInWords}</span>
            </div>

            <div className="pt-1 border-t border-slate-300">
              <span className="font-bold text-slate-700">Payment Mode: </span>
              <strong className="text-slate-950 uppercase">{invoice.paymentMode}</strong>
            </div>

            {invoice.financierDetails && (
              <div className="bg-slate-50 p-1.5 border border-slate-300 rounded-xs text-[9px] space-y-0.5">
                <div>Financier: <strong className="text-slate-950">{invoice.financierDetails.financierName}</strong></div>
                <div>Approval / DO No: <strong className="font-mono text-slate-950">{invoice.financierDetails.approvalNo}</strong></div>
                {invoice.financierDetails.schemeCode && (
                  <div>Scheme: <span className="font-mono text-slate-800">{invoice.financierDetails.schemeCode}</span></div>
                )}
              </div>
            )}
          </div>

          {/* Right Column: Tax Summary Table */}
          <div className="col-span-6">
            <table className="w-full border-collapse border border-slate-800 text-[9px]">
              <thead>
                <tr className="bg-slate-100 font-bold border-b border-slate-800">
                  <th className="border border-slate-800 p-1 text-center">Tax Type</th>
                  <th className="border border-slate-800 p-1 text-center">GST %</th>
                  <th className="border border-slate-800 p-1 text-right">Taxable Amt</th>
                  <th className="border border-slate-800 p-1 text-right">Tax Amount</th>
                </tr>
              </thead>
              <tbody>
                {invoice.isInterState ? (
                  <tr>
                    <td className="border border-slate-800 p-1 font-semibold text-center">Integrated Tax (IGST)</td>
                    <td className="border border-slate-800 p-1 text-center font-mono">18%</td>
                    <td className="border border-slate-800 p-1 text-right font-mono">₹{invoice.subTotalTaxable.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                    <td className="border border-slate-800 p-1 text-right font-mono">₹{invoice.totalIgst.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                  </tr>
                ) : (
                  <>
                    <tr>
                      <td className="border border-slate-800 p-1 font-semibold text-center">Central Tax (CGST)</td>
                      <td className="border border-slate-800 p-1 text-center font-mono">9%</td>
                      <td className="border border-slate-800 p-1 text-right font-mono">₹{invoice.subTotalTaxable.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                      <td className="border border-slate-800 p-1 text-right font-mono">₹{invoice.totalCgst.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                    </tr>
                    <tr>
                      <td className="border border-slate-800 p-1 font-semibold text-center">State Tax (SGST)</td>
                      <td className="border border-slate-800 p-1 text-center font-mono">9%</td>
                      <td className="border border-slate-800 p-1 text-right font-mono">₹{invoice.subTotalTaxable.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                      <td className="border border-slate-800 p-1 text-right font-mono">₹{invoice.totalSgst.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                    </tr>
                  </>
                )}
                <tr className="bg-slate-100 font-bold border-t border-slate-800">
                  <td colSpan={3} className="border border-slate-800 p-1 text-right pr-2">Total Tax:</td>
                  <td className="border border-slate-800 p-1 text-right font-mono font-bold text-slate-950">
                    ₹{invoice.totalTax.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                  </td>
                </tr>
                <tr className="bg-slate-200 font-black border-t-2 border-slate-900 text-[11px]">
                  <td colSpan={3} className="border border-slate-800 p-1 text-right pr-2">NET INVOICE TOTAL:</td>
                  <td className="border border-slate-800 p-1 text-right font-mono text-slate-950 font-black">
                    ₹{invoice.netTotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* 6. Footer Terms & Conditions (1 to 11) */}
        <div className="border border-slate-400 p-2 my-2 text-[8px] leading-snug text-slate-600 bg-slate-50/50">
          <div className="font-bold text-slate-800 uppercase mb-1">Terms & Conditions of Sale:</div>
          <ol className="list-decimal list-inside space-y-0.5">
            <li>Goods once sold will not be taken back or exchanged under any circumstances.</li>
            <li>Warranty for all mobile handsets and accessories is provided exclusively by their respective manufacturer service centers as per brand warranty policy.</li>
            <li>Physical damage, liquid / water logging, electrical surge, display crack, or tampered warranty seals are strictly NOT covered under brand warranty.</li>
            <li>Original purchase tax invoice must be produced at authorized service centers for claiming warranty or repair.</li>
            <li>Any manufacturing defect reported within 24 hours of purchase will be routed via the brand DOA (Dead on Arrival) policy as per manufacturer guidelines.</li>
            <li>For devices financed through finance companies (e.g. Bajaj, Poonawalla, etc.), ownership remains subject to loan fulfillment and NOC clearance.</li>
            <li>Batteries, chargers, and data cables carry warranty as designated by the original device manufacturer (typically 6 months).</li>
            <li>The store will not be liable for any customer data loss or backup during handset servicing or repairs.</li>
            <li>Interest @ 18% per annum will be charged if payment is not cleared on or before the due date.</li>
            <li>All taxes are charged strictly in accordance with GST Rules & Regulations 2017.</li>
            <li>All disputes and legal claims are strictly subject to Ahmedabad Jurisdiction only.</li>
          </ol>
        </div>

        {/* 7. Bottom Verification & Stamp Block */}
        <div className="grid grid-cols-12 gap-3 pt-2 border-t-2 border-slate-900 items-end text-[9px]">
          {/* Left: Dynamic QR Code Box */}
          <div className="col-span-4 flex items-center gap-2 border border-slate-400 p-1.5 rounded-xs">
            {qrCodeDataUrl ? (
              <img src={qrCodeDataUrl} alt="GST QR Code" className="w-16 h-16 object-contain" />
            ) : (
              <div className="w-16 h-16 bg-slate-100 border border-dashed border-slate-400 flex items-center justify-center text-[8px] text-slate-400">
                QR CODE
              </div>
            )}
            <div className="space-y-0.5 text-[8px] text-slate-600 leading-tight">
              <div><strong>UID:</strong> {invoice.uid}</div>
              <div><strong>Ack Date:</strong> {invoice.ackDate}</div>
              <div><strong>Category:</strong> {invoice.category}</div>
              <div className="text-emerald-700 font-bold">✓ Tax Verified</div>
            </div>
          </div>

          {/* Middle: Due Date & Digital Disclaimer */}
          <div className="col-span-4 text-center px-1">
            <div className="text-[10px] text-slate-700">Due Date: <strong>{invoice.dueDate}</strong></div>
            <p className="text-[7.5px] text-slate-500 italic mt-2 leading-tight">
              &quot;This document is electronically generated and digitally signed; therefore, it does not require a handwritten signature.&quot;
            </p>
          </div>

          {/* Right: Store Stamp & Authorized Signatory Block */}
          <div className="col-span-4 text-right">
            <div className="text-[9px] font-bold text-slate-800">
              for {invoice.storeDetails.name}
            </div>
            {/* Stamp simulation */}
            <div className="my-2 flex justify-end">
              <div className="border border-blue-800/40 text-blue-900/60 rounded px-2 py-1 text-[7.5px] uppercase font-bold transform -rotate-2 border-dashed inline-block">
                ★ AUTH STORE SEAL ★<br />AHMEDABAD
              </div>
            </div>
            <div className="text-[9px] font-semibold text-slate-900 border-t border-slate-800 pt-1 inline-block min-w-[130px]">
              Authorized Signatory
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
