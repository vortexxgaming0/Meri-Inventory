import React, { useState } from 'react';
import { InventoryItem } from '../types';
import { Search, Filter, Copy, Check, Smartphone, CheckCircle, Clock, ShoppingBag } from 'lucide-react';

interface InventoryManagerProps {
  inventory: InventoryItem[];
  onNavigateToStockIn?: () => void;
}

export const InventoryManager: React.FC<InventoryManagerProps> = ({ inventory, onNavigateToStockIn }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'AVAILABLE' | 'SOLD'>('ALL');
  const [brandFilter, setBrandFilter] = useState<string>('ALL');
  const [copiedImei, setCopiedImei] = useState<string | null>(null);

  // Extract unique brands
  const brands = Array.from(new Set(inventory.map((i) => i.brand))).filter(Boolean);

  const filteredItems = inventory.filter((item) => {
    const matchesSearch =
      item.imei.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.model.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.brand.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (item.customerName && item.customerName.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (item.invoiceId && item.invoiceId.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesStatus = statusFilter === 'ALL' || item.status === statusFilter;
    const matchesBrand = brandFilter === 'ALL' || item.brand === brandFilter;

    return matchesSearch && matchesStatus && matchesBrand;
  });

  const handleCopyImei = (imei: string) => {
    navigator.clipboard.writeText(imei);
    setCopiedImei(imei);
    setTimeout(() => setCopiedImei(null), 1800);
  };

  const availableCount = inventory.filter((i) => i.status === 'AVAILABLE').length;
  const soldCount = inventory.filter((i) => i.status === 'SOLD').length;
  const totalStockValue = inventory
    .filter((i) => i.status === 'AVAILABLE')
    .reduce((sum, i) => sum + i.purchaseRate, 0);

  return (
    <div className="space-y-6">
      {/* Top Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Available Stock</span>
            <div className="text-2xl font-black text-slate-900 mt-1">{availableCount} Units</div>
            <span className="text-xs text-emerald-600 font-medium">Ready for POS Billing</span>
          </div>
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
            <CheckCircle className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Sold Units</span>
            <div className="text-2xl font-black text-slate-900 mt-1">{soldCount} Units</div>
            <span className="text-xs text-indigo-600 font-medium">Invoiced & Dispatched</span>
          </div>
          <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl">
            <ShoppingBag className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">In-Stock Valuation</span>
            <div className="text-2xl font-black text-slate-900 mt-1 font-mono">
              ₹{totalStockValue.toLocaleString('en-IN')}
            </div>
            <span className="text-xs text-slate-400">At Purchase Cost</span>
          </div>
          <div className="p-3 bg-blue-50 text-blue-600 rounded-xl">
            <Smartphone className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Search by 15-digit IMEI, Model, Customer, or Invoice No..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 border border-slate-300 rounded-xl text-xs font-mono focus:ring-2 focus:ring-indigo-500 outline-none"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Status filter tabs */}
          <div className="inline-flex rounded-xl bg-slate-100 p-1 border border-slate-200">
            {(['ALL', 'AVAILABLE', 'SOLD'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setStatusFilter(tab)}
                className={`text-xs font-bold px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                  statusFilter === tab
                    ? 'bg-white text-indigo-950 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>

          {/* Brand select */}
          <select
            value={brandFilter}
            onChange={(e) => setBrandFilter(e.target.value)}
            className="text-xs border border-slate-300 rounded-xl px-3 py-2 bg-white font-medium text-slate-800 outline-none"
          >
            <option value="ALL">All Brands</option>
            {brands.map((b) => (
              <option key={b} value={b}>
                {b}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Inventory Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 font-bold uppercase tracking-wider text-[10px]">
              <tr>
                <th className="py-3 px-4">Device & Specifications</th>
                <th className="py-3 px-4">Unique 15-Digit IMEI</th>
                <th className="py-3 px-4">HSN Code</th>
                <th className="py-3 px-4 text-right">Purchase (Cost)</th>
                <th className="py-3 px-4 text-right">Selling (MOP)</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4">Distributor / Inward Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {inventory.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-12 px-4">
                    <div className="max-w-md mx-auto space-y-3">
                      <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto">
                        <Smartphone className="w-6 h-6" />
                      </div>
                      <h4 className="text-sm font-bold text-slate-900">Your Inventory is Currently Blank</h4>
                      <p className="text-xs text-slate-500">
                        No handsets or stock units have been added yet. Your inventory stays blank and only records and displays what you enter.
                      </p>
                      {onNavigateToStockIn && (
                        <button
                          onClick={onNavigateToStockIn}
                          className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs px-4 py-2 rounded-xl transition-all shadow-xs cursor-pointer"
                        >
                          Add First Stock in Stock IN
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ) : filteredItems.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-8 text-slate-400">
                    No matching inventory units found.
                  </td>
                </tr>
              ) : (
                filteredItems.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900 text-sm">
                        {item.brand} {item.model}
                      </div>
                      <div className="text-slate-500 text-[11px]">
                        {item.specs} • {item.color}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="inline-flex items-center gap-1.5 font-mono text-xs bg-slate-100 px-2 py-1 rounded border border-slate-200">
                        <span className="font-semibold text-slate-900">{item.imei}</span>
                        <button
                          onClick={() => handleCopyImei(item.imei)}
                          className="text-slate-400 hover:text-indigo-600 p-0.5 cursor-pointer"
                          title="Copy IMEI to clipboard"
                        >
                          {copiedImei === item.imei ? (
                            <Check className="w-3.5 h-3.5 text-emerald-600" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-600">{item.hsn}</td>
                    <td className="py-3 px-4 text-right font-mono text-slate-600">
                      ₹{item.purchaseRate.toLocaleString('en-IN')}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                      ₹{item.sellingPrice.toLocaleString('en-IN')}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span
                        className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          item.status === 'AVAILABLE'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-slate-200 text-slate-700'
                        }`}
                      >
                        {item.status === 'AVAILABLE' ? 'AVAILABLE' : 'SOLD'}
                      </span>
                      {item.status === 'SOLD' && item.invoiceId && (
                        <div className="text-[10px] text-slate-500 font-mono mt-0.5">{item.invoiceId}</div>
                      )}
                    </td>
                    <td className="py-3 px-4 text-[11px] text-slate-600">
                      <div className="font-medium text-slate-800">{item.supplierName}</div>
                      <div className="text-slate-400 text-[10px]">{item.inwardDate}</div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
