import React, { useState } from 'react';
import { StoreProfile, ShopCategory, Salesperson } from '../types';
import { INDIAN_STATES, playScannerBeep } from '../data/mockBills';
import {
  X,
  Store,
  Check,
  Building2,
  Users,
  UserPlus,
  Edit2,
  Trash2,
  Save,
  AlertCircle,
  Plus,
} from 'lucide-react';

interface StoreProfileModalProps {
  store: StoreProfile;
  isOpen: boolean;
  onClose: () => void;
  onUpdate: (updatedStore: StoreProfile) => void;
}

export const StoreProfileModal: React.FC<StoreProfileModalProps> = ({
  store,
  isOpen,
  onClose,
  onUpdate,
}) => {
  const [activeTab, setActiveTab] = useState<'DETAILS' | 'SALESPERSONS'>('DETAILS');

  // Store profile fields
  const [name, setName] = useState(store.name);
  const [category, setCategory] = useState<ShopCategory>(store.category);
  const [ownerName, setOwnerName] = useState(store.ownerName);
  const [mobile, setMobile] = useState(store.mobile);
  const [email, setEmail] = useState(store.email);
  const [shopNo, setShopNo] = useState(store.shopNo);
  const [address, setAddress] = useState(store.address);
  const [city, setCity] = useState(store.city || '');
  const [stateCode, setStateCode] = useState(store.stateCode || '24');
  const [hasGst, setHasGst] = useState(store.hasGst);
  const [gstin, setGstin] = useState(store.gstin || '');
  const [pan, setPan] = useState(store.pan || '');
  const [invoicePrefix, setInvoicePrefix] = useState(store.invoicePrefix || 'INV-');

  // Salespersons list state
  const [salespersons, setSalespersons] = useState<Salesperson[]>(store.salespersons || []);

  // Add Salesperson inline state
  const [newSpName, setNewSpName] = useState('');
  const [newSpRole, setNewSpRole] = useState('Sales Executive');
  const [newSpCode, setNewSpCode] = useState('');
  const [isAddingSp, setIsAddingSp] = useState(false);

  // Edit Salesperson state
  const [editingSpId, setEditingSpId] = useState<string | null>(null);
  const [editingSpName, setEditingSpName] = useState('');
  const [editingSpRole, setEditingSpRole] = useState('');
  const [editingSpCode, setEditingSpCode] = useState('');

  const [isSaving, setIsSaving] = useState(false);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  // Handle General Store Save
  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setStatusMsg(null);
    setErrorMsg(null);

    const st = INDIAN_STATES.find((s) => s.code === stateCode) || INDIAN_STATES[0];

    try {
      const res = await fetch('/api/store/setup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          category,
          ownerName,
          mobile,
          email,
          shopNo,
          address,
          city,
          state: st.name,
          stateCode: st.code,
          hasGst,
          gstin: hasGst ? gstin.trim().toUpperCase() : undefined,
          pan: hasGst ? pan.trim().toUpperCase() : undefined,
          invoicePrefix,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) throw new Error(data.error || 'Failed to update store');

      setStatusMsg('Store profile updated successfully!');
      onUpdate(data.store);
      setTimeout(() => {
        onClose();
      }, 1000);
    } catch (err: any) {
      setErrorMsg(err.message);
    } finally {
      setIsSaving(false);
    }
  };

  // Add Salesperson via API
  const handleAddSalesperson = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSpName.trim()) return;

    setIsAddingSp(true);
    setErrorMsg(null);
    try {
      const res = await fetch('/api/salespersons', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: newSpName.trim(),
          role: newSpRole.trim() || 'Sales Executive',
          code: newSpCode.trim(),
        }),
      });
      const data = await res.json();
      if (!res.ok || !data.success) throw new Error(data.error || 'Failed to add salesperson');

      setSalespersons(data.salespersons);
      onUpdate({ ...store, salespersons: data.salespersons });
      setNewSpName('');
      setNewSpRole('Sales Executive');
      setNewSpCode('');
      setStatusMsg(`Added ${data.salesperson.name} successfully!`);
      setTimeout(() => setStatusMsg(null), 3000);
      playScannerBeep('success');
    } catch (err: any) {
      setErrorMsg(err.message);
      playScannerBeep('error');
    } finally {
      setIsAddingSp(false);
    }
  };

  // Save Edited Salesperson Name
  const handleSaveEditSalesperson = async (id: string) => {
    if (!editingSpName.trim()) return;

    try {
      const res = await fetch(`/api/salespersons/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: editingSpName.trim(),
          role: editingSpRole.trim(),
          code: editingSpCode.trim(),
        }),
      });
      const data = await res.json();
      if (!res.ok || !data.success) throw new Error(data.error || 'Failed to update salesperson');

      setSalespersons(data.salespersons);
      onUpdate({ ...store, salespersons: data.salespersons });
      setEditingSpId(null);
      setStatusMsg('Salesperson updated!');
      setTimeout(() => setStatusMsg(null), 2500);
      playScannerBeep('success');
    } catch (err: any) {
      setErrorMsg(err.message);
      playScannerBeep('error');
    }
  };

  // Delete Salesperson
  const handleDeleteSalesperson = async (id: string, spName: string) => {
    if (!window.confirm(`Are you sure you want to remove ${spName}?`)) return;

    try {
      const res = await fetch(`/api/salespersons/${id}`, {
        method: 'DELETE',
      });
      const data = await res.json();
      if (!res.ok || !data.success) throw new Error(data.error || 'Failed to delete');

      setSalespersons(data.salespersons);
      onUpdate({ ...store, salespersons: data.salespersons });
      setStatusMsg('Salesperson removed');
      setTimeout(() => setStatusMsg(null), 2500);
    } catch (err: any) {
      setErrorMsg(err.message);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-xl w-full p-6 max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-200">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-indigo-50 text-indigo-700 rounded-xl">
              <Store className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">Store Profile & Settings</h3>
              <p className="text-xs text-slate-500">Manage business identity, GST & sales staff</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-700 p-1 rounded-lg cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-2 mt-4 p-1 bg-slate-100 rounded-xl border border-slate-200">
          <button
            type="button"
            onClick={() => setActiveTab('DETAILS')}
            className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
              activeTab === 'DETAILS'
                ? 'bg-white text-indigo-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            Shop & GST Details
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('SALESPERSONS')}
            className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
              activeTab === 'SALESPERSONS'
                ? 'bg-white text-indigo-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            Salespersons ({salespersons.length})
          </button>
        </div>

        {/* Feedback Notifications */}
        {statusMsg && (
          <div className="mt-3 p-3 bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs rounded-xl flex items-center gap-2 font-medium">
            <Check className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{statusMsg}</span>
          </div>
        )}
        {errorMsg && (
          <div className="mt-3 p-3 bg-rose-50 border border-rose-200 text-rose-900 text-xs rounded-xl flex items-center gap-2 font-medium">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* TAB 1: STORE & GST DETAILS */}
        {activeTab === 'DETAILS' && (
          <form onSubmit={handleSave} className="space-y-4 mt-4 text-xs">
            <div>
              <label className="font-bold text-slate-700 block mb-1">Store / Business Name *</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. ARYA MOBILE & ACCESSORIES"
                className="w-full border border-slate-300 rounded-lg px-3 py-2 font-bold text-slate-900 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Shop Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as ShopCategory)}
                  className="w-full border border-slate-300 rounded-lg px-2.5 py-2 font-medium bg-white focus:ring-2 focus:ring-indigo-500 outline-none"
                >
                  <option value="RETAIL">Exclusive Retail Store</option>
                  <option value="WHOLESALE">Wholesale & Distributor</option>
                  <option value="RETAIL_SERVICE">Retail & Service Center</option>
                  <option value="ONLINE_HYBRID">Omnichannel & Hybrid Store</option>
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Owner / Manager Name</label>
                <input
                  type="text"
                  value={ownerName}
                  onChange={(e) => setOwnerName(e.target.value)}
                  placeholder="e.g. Chirag Dave"
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 font-medium focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Shop / Unit No.</label>
                <input
                  type="text"
                  value={shopNo}
                  onChange={(e) => setShopNo(e.target.value)}
                  placeholder="e.g. Shop 14, Ground Floor"
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 font-medium focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>
              <div>
                <label className="font-bold text-slate-700 block mb-1">Contact Mobile</label>
                <input
                  type="text"
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value)}
                  placeholder="98250 11442"
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 font-mono font-medium focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">Street Address / Complex</label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="e.g. MG Road, Near City Mall"
                className="w-full border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="font-bold text-slate-700 block mb-1">City</label>
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="e.g. Ahmedabad"
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>
              <div>
                <label className="font-bold text-slate-700 block mb-1">State (Place of Supply)</label>
                <select
                  value={stateCode}
                  onChange={(e) => setStateCode(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg px-2.5 py-2 font-medium bg-white focus:ring-2 focus:ring-indigo-500 outline-none"
                >
                  {INDIAN_STATES.map((s) => (
                    <option key={s.code} value={s.code}>
                      {s.name} ({s.code})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* GST Toggle & Inputs */}
            <div className="pt-2 border-t border-slate-200">
              <div className="flex items-center justify-between mb-2">
                <div>
                  <span className="font-bold text-slate-800">GST Registration (Optional)</span>
                  <p className="text-[11px] text-slate-400">Keep unchecked if non-GST / composition dealer</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={hasGst}
                    onChange={(e) => setHasGst(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-600"></div>
                </label>
              </div>

              {hasGst && (
                <div className="grid grid-cols-2 gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <div>
                    <label className="font-bold text-slate-600 block mb-0.5">GSTIN (15 Digits)</label>
                    <input
                      type="text"
                      maxLength={15}
                      value={gstin}
                      onChange={(e) => setGstin(e.target.value.toUpperCase())}
                      placeholder="e.g. 24AAECS9124L1ZM"
                      className="w-full border border-slate-300 rounded px-2.5 py-1.5 font-mono uppercase font-bold text-slate-900"
                    />
                  </div>
                  <div>
                    <label className="font-bold text-slate-600 block mb-0.5">PAN Number</label>
                    <input
                      type="text"
                      maxLength={10}
                      value={pan}
                      onChange={(e) => setPan(e.target.value.toUpperCase())}
                      placeholder="e.g. AAECS9124L"
                      className="w-full border border-slate-300 rounded px-2.5 py-1.5 font-mono uppercase"
                    />
                  </div>
                </div>
              )}
            </div>

            <div className="pt-2 border-t border-slate-200 flex justify-end gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-slate-600 hover:text-slate-900 font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSaving}
                className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold px-5 py-2 rounded-xl transition-all cursor-pointer shadow-sm disabled:opacity-50"
              >
                <Save className="w-3.5 h-3.5" />
                {isSaving ? 'Saving...' : 'Save Profile'}
              </button>
            </div>
          </form>
        )}

        {/* TAB 2: SALESPERSONS & STAFF MANAGEMENT */}
        {activeTab === 'SALESPERSONS' && (
          <div className="space-y-4 mt-4 text-xs">
            {/* Add New Salesperson Form */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
              <div className="font-bold text-slate-900 flex items-center gap-1.5">
                <UserPlus className="w-4 h-4 text-indigo-600" />
                Add New Salesperson
              </div>
              <form onSubmit={handleAddSalesperson} className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <input
                  type="text"
                  required
                  placeholder="Salesperson Name *"
                  value={newSpName}
                  onChange={(e) => setNewSpName(e.target.value)}
                  className="border border-slate-300 rounded-lg px-3 py-2 text-xs bg-white text-slate-900 font-bold focus:ring-2 focus:ring-indigo-500 outline-none"
                />
                <input
                  type="text"
                  placeholder="Role (e.g. Store Executive)"
                  value={newSpRole}
                  onChange={(e) => setNewSpRole(e.target.value)}
                  className="border border-slate-300 rounded-lg px-3 py-2 text-xs bg-white text-slate-900 focus:ring-2 focus:ring-indigo-500 outline-none"
                />
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Emp ID (e.g. EMP-101)"
                    value={newSpCode}
                    onChange={(e) => setNewSpCode(e.target.value)}
                    className="border border-slate-300 rounded-lg px-3 py-2 text-xs font-mono uppercase bg-white text-slate-900 flex-1 focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                  <button
                    type="submit"
                    disabled={isAddingSp || !newSpName.trim()}
                    className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-3 py-2 rounded-lg transition-all cursor-pointer shadow-xs disabled:opacity-50 shrink-0"
                  >
                    Add
                  </button>
                </div>
              </form>
            </div>

            {/* List of Configured Salespersons */}
            <div className="space-y-2">
              <div className="font-bold text-slate-700 flex items-center justify-between">
                <span>Configured Counter Staff ({salespersons.length})</span>
                <span className="text-[11px] text-slate-400">Click edit icon to rename</span>
              </div>

              {salespersons.length === 0 ? (
                <div className="text-center py-8 border-2 border-dashed border-slate-200 rounded-xl text-slate-400">
                  <Users className="w-8 h-8 mx-auto mb-2 text-slate-300" />
                  <p className="font-medium">No salespersons added yet.</p>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Add counter executives above to record them on tax invoices and filter reports.
                  </p>
                </div>
              ) : (
                <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden bg-white">
                  {salespersons.map((sp) => (
                    <div key={sp.id} className="p-3 flex items-center justify-between hover:bg-slate-50/80 transition-colors">
                      {editingSpId === sp.id ? (
                        <div className="flex-1 flex items-center gap-2 mr-2">
                          <input
                            type="text"
                            value={editingSpName}
                            onChange={(e) => setEditingSpName(e.target.value)}
                            placeholder="Name"
                            className="border border-indigo-300 rounded px-2 py-1 text-xs font-bold flex-1"
                            autoFocus
                          />
                          <input
                            type="text"
                            value={editingSpRole}
                            onChange={(e) => setEditingSpRole(e.target.value)}
                            placeholder="Role"
                            className="border border-slate-300 rounded px-2 py-1 text-xs flex-1"
                          />
                          <input
                            type="text"
                            value={editingSpCode}
                            onChange={(e) => setEditingSpCode(e.target.value)}
                            placeholder="Code"
                            className="border border-slate-300 rounded px-2 py-1 text-xs font-mono uppercase w-20"
                          />
                          <button
                            type="button"
                            onClick={() => handleSaveEditSalesperson(sp.id)}
                            className="bg-emerald-600 text-white px-2.5 py-1 rounded text-xs font-bold cursor-pointer hover:bg-emerald-500"
                          >
                            Save
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingSpId(null)}
                            className="text-slate-400 hover:text-slate-600 px-1 text-xs cursor-pointer"
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <div>
                          <div className="font-bold text-slate-900 text-xs flex items-center gap-2">
                            <span>{sp.name}</span>
                            {sp.code && (
                              <span className="font-mono text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded border border-slate-200">
                                {sp.code}
                              </span>
                            )}
                          </div>
                          <div className="text-slate-500 text-[11px] mt-0.5">
                            {sp.role || 'Sales Staff'}
                          </div>
                        </div>
                      )}

                      {editingSpId !== sp.id && (
                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => {
                              setEditingSpId(sp.id);
                              setEditingSpName(sp.name);
                              setEditingSpRole(sp.role || '');
                              setEditingSpCode(sp.code || '');
                            }}
                            className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg cursor-pointer transition-colors"
                            title="Edit salesperson name"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteSalesperson(sp.id, sp.name)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg cursor-pointer transition-colors"
                            title="Remove salesperson"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="pt-3 border-t border-slate-200 flex justify-end">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl font-bold text-xs cursor-pointer"
              >
                Close Settings
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
