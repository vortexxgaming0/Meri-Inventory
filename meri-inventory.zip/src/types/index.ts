export interface InventoryItem {
  id: string;
  imei: string;
  brand: string;
  model: string;
  color: string;
  specs: string; // e.g. "8GB / 256GB"
  hsn: string;
  purchaseRate: number; // Excl. GST
  sellingPrice: number; // Incl. GST
  gstPercent: number;
  status: 'AVAILABLE' | 'SOLD';
  supplierName: string;
  supplierBillNo: string;
  inwardDate: string;
  soldDate?: string;
  invoiceId?: string;
  customerName?: string;
}

export interface ExtractedBillItem {
  brand: string;
  model: string;
  specs: string;
  color: string;
  hsn: string;
  qty: number;
  purchaseRate: number;
  gstPercent: number;
  sellingPrice: number;
  imeiList: string[];
}

export interface ExtractedBillData {
  supplierName: string;
  supplierBillNo: string;
  billDate: string;
  items: ExtractedBillItem[];
}

export interface InvoiceItem {
  sNo: number;
  code: string;
  itemCode: string;
  particulars: string;
  hsn: string;
  qty: number;
  rate: number;
  gstPercent: number;
  amount: number;
  imei: string;
}

export interface TaxSummaryRow {
  gstPercent: number;
  taxableAmt: number;
  igstAmt: number;
  cgstAmt: number;
  sgstAmt: number;
  total: number;
}

export interface InvoiceRecord {
  id: string;
  invoiceNo: string;
  invoiceDate: string;
  invoiceTime: string;
  salesperson: string;
  salespersonId: string;
  billTo: {
    customerName: string;
    mobile: string;
    address: string;
    state: string;
    stateCode: string;
    gstin?: string;
  };
  shipTo: {
    name: string;
    address: string;
    state: string;
    stateCode: string;
  };
  placeOfSupply: string;
  isInterState: boolean;
  paymentMode: 'Cash' | 'UPI' | 'Card' | 'Finance';
  financierDetails?: {
    financierName: string;
    approvalNo: string;
    schemeCode?: string;
  };
  items: InvoiceItem[];
  subTotalTaxable: number;
  totalCgst: number;
  totalSgst: number;
  totalIgst: number;
  totalTax: number;
  netTotal: number;
  amountInWords: string;
  storeDetails: {
    name: string;
    shopNo: string;
    address: string;
    phones: string[];
    gstin: string;
    pan: string;
    state: string;
    stateCode: string;
    cin: string;
    email: string;
  };
  uid: string;
  ackDate: string;
  category: string;
  dueDate: string;
}

export type ShopCategory = 'RETAIL' | 'WHOLESALE' | 'RETAIL_SERVICE' | 'ONLINE_HYBRID';

export interface Salesperson {
  id: string;
  name: string;
  role?: string;
  code?: string;
  mobile?: string;
}

export interface StoreProfile {
  id: string;
  name: string;
  category: ShopCategory;
  categoryLabel: string;
  scale: 'SOLO' | 'SMALL' | 'ENTERPRISE';
  ownerName: string;
  mobile: string;
  email: string;
  shopNo: string;
  address: string;
  city: string;
  state: string;
  stateCode: string;
  hasGst: boolean;
  gstin?: string;
  pan?: string;
  cin?: string;
  phones: string[];
  invoicePrefix: string;
  isConfigured: boolean;
  setupDate?: string;
  salespersons: Salesperson[];
}

export interface UserSession {
  mobile: string;
  isLoggedIn: boolean;
  token?: string;
  loginTime?: string;
}
