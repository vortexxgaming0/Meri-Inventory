// Realistic Distributor Purchase Bills and Metadata

export const INDIAN_STATES = [
  { code: '24', name: 'Gujarat' },
  { code: '27', name: 'Maharashtra' },
  { code: '08', name: 'Rajasthan' },
  { code: '07', name: 'Delhi' },
  { code: '29', name: 'Karnataka' },
  { code: '33', name: 'Tamil Nadu' },
  { code: '09', name: 'Uttar Pradesh' },
  { code: '23', name: 'Madhya Pradesh' },
  { code: '19', name: 'West Bengal' },
  { code: '36', name: 'Telangana' },
  { code: '06', name: 'Haryana' },
  { code: '03', name: 'Punjab' },
];

export const FINANCIERS = [
  { id: 'poonawalla', name: 'Poonawalla Fincorp Ltd', defaultScheme: '0% EMI 8/2 Scheme' },
  { id: 'bajaj', name: 'Bajaj Finserv Ltd', defaultScheme: 'Easy EMI 10/2 Scheme' },
  { id: 'tvs', name: 'TVS Credit Services', defaultScheme: 'Mobile Loan 6/1 Scheme' },
  { id: 'hdb', name: 'HDB Financial Services', defaultScheme: 'Festive Zero Downpayment' },
  { id: 'idfc', name: 'IDFC First Bank Consumer Durable', defaultScheme: 'Smart Buy EMI' },
  { id: 'homecredit', name: 'Home Credit India', defaultScheme: 'Easy Phone 12 Months' },
];

export const SALESPERSONS: { id: string; name: string; role?: string }[] = [];

// High-resolution synthetic distributor bill SVG generators for instant OCR testing
export interface DemoBillSample {
  id: string;
  title: string;
  distributorName: string;
  billNo: string;
  date: string;
  deviceSummary: string;
  itemCount: number;
  totalAmount: number;
  previewSvgDataUri: string;
  extractedMock: {
    supplierName: string;
    supplierBillNo: string;
    billDate: string;
    items: {
      brand: string;
      model: string;
      specs: string;
      color: string;
      hsn: string;
      qty: number;
      purchaseRate: number;
      gstPercent: number;
      sellingPrice: number;
      imeiList: string[];
    }[];
  };
}

// Generate an SVG data URI that looks like a real scanned distributor tax invoice
function createInvoiceSvg(
  supplier: string,
  billNo: string,
  date: string,
  items: { desc: string; hsn: string; qty: number; rate: number; imeis: string[] }[]
): string {
  const itemRows = items
    .map(
      (it, idx) => `
    <tr style="border-bottom: 1px solid #cbd5e1;">
      <td style="padding: 6px; font-size: 11px;">${idx + 1}</td>
      <td style="padding: 6px; font-size: 11px; font-weight: bold;">
        ${it.desc}
        <div style="font-family: monospace; font-size: 9px; color: #475569; margin-top: 3px;">
          IMEI: ${it.imeis.join(', ')}
        </div>
      </td>
      <td style="padding: 6px; font-size: 11px; text-align: center;">${it.hsn}</td>
      <td style="padding: 6px; font-size: 11px; text-align: center;">${it.qty}</td>
      <td style="padding: 6px; font-size: 11px; text-align: right;">₹${it.rate.toLocaleString('en-IN')}</td>
      <td style="padding: 6px; font-size: 11px; text-align: right;">18%</td>
      <td style="padding: 6px; font-size: 11px; text-align: right; font-weight: bold;">₹${(it.rate * it.qty).toLocaleString('en-IN')}</td>
    </tr>
  `
    )
    .join('');

  const totalBase = items.reduce((sum, it) => sum + it.rate * it.qty, 0);
  const gst = totalBase * 0.18;
  const net = totalBase + gst;

  const html = `
  <svg xmlns="http://www.w3.org/2000/svg" width="700" height="920" viewBox="0 0 700 920">
    <rect width="100%" height="100%" fill="#ffffff" />
    <foreignObject width="100%" height="100%">
      <div xmlns="http://www.w3.org/1999/xhtml" style="font-family: Arial, sans-serif; padding: 25px; color: #0f172a; box-sizing: border-box; background: #fff; height: 100%;">
        <div style="text-align: center; border-bottom: 2px solid #0f172a; padding-bottom: 12px; margin-bottom: 12px;">
          <h2 style="margin: 0; font-size: 18px; text-transform: uppercase; color: #1e293b;">${supplier}</h2>
          <p style="margin: 3px 0; font-size: 10px; color: #64748b;">Authorised National Mobile & IT Distributor | GSTIN: 27AABCR9914L1ZN</p>
          <p style="margin: 2px 0; font-size: 10px; color: #64748b;">Warehouse: Bhiwandi Logistics Hub, Thane - 421302 | Ph: 022-68994411</p>
          <div style="display: inline-block; background: #0f172a; color: #fff; font-size: 11px; font-weight: bold; padding: 2px 14px; margin-top: 5px; border-radius: 2px;">
            TAX INVOICE / PURCHASE MEMO
          </div>
        </div>

        <div style="display: flex; justify-content: space-between; font-size: 11px; margin-bottom: 14px; border: 1px solid #cbd5e1; padding: 8px; border-radius: 4px; background: #f8fafc;">
          <div>
            <div><strong>Invoice No:</strong> ${billNo}</div>
            <div><strong>Date:</strong> ${date}</div>
            <div><strong>Supply Type:</strong> Intra-State B2B</div>
          </div>
          <div>
            <div><strong>Billed To:</strong> SHIVAM MOBILE & ELECTRONICS PVT LTD</div>
            <div><strong>GSTIN:</strong> 24AAECS9124L1ZM</div>
            <div><strong>Place of Supply:</strong> Gujarat (24)</div>
          </div>
        </div>

        <table style="width: 100%; border-collapse: collapse; margin-bottom: 15px; border: 1px solid #cbd5e1;">
          <thead>
            <tr style="background: #e2e8f0; border-bottom: 1px solid #94a3b8;">
              <th style="padding: 6px; font-size: 10px; text-align: left;">#</th>
              <th style="padding: 6px; font-size: 10px; text-align: left;">Product Description & Serial Numbers</th>
              <th style="padding: 6px; font-size: 10px; text-align: center;">HSN</th>
              <th style="padding: 6px; font-size: 10px; text-align: center;">Qty</th>
              <th style="padding: 6px; font-size: 10px; text-align: right;">Unit Rate</th>
              <th style="padding: 6px; font-size: 10px; text-align: right;">GST%</th>
              <th style="padding: 6px; font-size: 10px; text-align: right;">Taxable Amount</th>
            </tr>
          </thead>
          <tbody>
            ${itemRows}
          </tbody>
        </table>

        <div style="display: flex; justify-content: flex-end; margin-bottom: 15px;">
          <div style="width: 250px; font-size: 11px; border: 1px solid #cbd5e1; padding: 8px; background: #f8fafc; border-radius: 4px;">
            <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
              <span>Subtotal Taxable:</span>
              <strong>₹${totalBase.toLocaleString('en-IN')}</strong>
            </div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
              <span>IGST (18%):</span>
              <strong>₹${gst.toLocaleString('en-IN')}</strong>
            </div>
            <div style="display: flex; justify-content: space-between; border-top: 1px solid #0f172a; padding-top: 4px; font-size: 13px; color: #0f172a;">
              <span>Total Invoice Value:</span>
              <strong>₹${net.toLocaleString('en-IN')}</strong>
            </div>
          </div>
        </div>

        <div style="font-size: 9px; color: #64748b; border-top: 1px solid #cbd5e1; padding-top: 8px;">
          <p style="margin: 2px 0;">* Electronic Stock Note: Please verify IMEI numbers before accepting consignment from courier.</p>
          <p style="margin: 2px 0;">* All disputes subject to Mumbai Jurisdiction.</p>
        </div>
      </div>
    </foreignObject>
  </svg>
  `;

  return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(html);
}

export const DEMO_PURCHASE_BILLS: DemoBillSample[] = [
  {
    id: 'bill-redington-apple',
    title: 'Redington India - Apple Consignment',
    distributorName: 'Redington India Ltd',
    billNo: 'RED-MUM-8921',
    date: '2026-09-20',
    deviceSummary: 'iPhone 15 Pro Max (2 Units) & iPhone 15 (1 Unit)',
    itemCount: 3,
    totalAmount: 349280,
    previewSvgDataUri: createInvoiceSvg('Redington India Limited', 'RED-MUM-8921', '20-09-2026', [
      {
        desc: 'Apple iPhone 15 Pro Max (256GB - Natural Titanium)',
        hsn: '85171300',
        qty: 2,
        rate: 118500,
        imeis: ['862947051284941', '862947051284942'],
      },
      {
        desc: 'Apple iPhone 15 (128GB - Black)',
        hsn: '85171300',
        qty: 1,
        rate: 59000,
        imeis: ['862947051284945'],
      },
    ]),
    extractedMock: {
      supplierName: 'Redington India Ltd',
      supplierBillNo: 'RED-MUM-8921',
      billDate: '2026-09-20',
      items: [
        {
          brand: 'Apple',
          model: 'iPhone 15 Pro Max',
          specs: '256GB / 8GB',
          color: 'Natural Titanium',
          hsn: '85171300',
          qty: 2,
          purchaseRate: 118500,
          gstPercent: 18,
          sellingPrice: 139900,
          imeiList: ['862947051284941', '862947051284942'],
        },
        {
          brand: 'Apple',
          model: 'iPhone 15',
          specs: '128GB / 6GB',
          color: 'Black',
          hsn: '85171300',
          qty: 1,
          purchaseRate: 59000,
          gstPercent: 18,
          sellingPrice: 69900,
          imeiList: ['862947051284945'],
        },
      ],
    },
  },
  {
    id: 'bill-samsung-balaji',
    title: 'Shree Balaji - Samsung Flagship Batch',
    distributorName: 'Shree Balaji Telecom Distributors',
    billNo: 'SBT-GJ-4412',
    date: '2026-09-22',
    deviceSummary: 'Galaxy S24 Ultra (1 Unit) & Galaxy A55 5G (2 Units)',
    itemCount: 3,
    totalAmount: 192340,
    previewSvgDataUri: createInvoiceSvg('Shree Balaji Telecom Distributors', 'SBT-GJ-4412', '22-09-2026', [
      {
        desc: 'Samsung Galaxy S24 Ultra 5G (12GB/512GB - Titanium Gray)',
        hsn: '85171300',
        qty: 1,
        rate: 104000,
        imeis: ['358941098234201'],
      },
      {
        desc: 'Samsung Galaxy A55 5G (8GB/128GB - Awesome Iceblue)',
        hsn: '85171300',
        qty: 2,
        rate: 29500,
        imeis: ['358941098234205', '358941098234206'],
      },
    ]),
    extractedMock: {
      supplierName: 'Shree Balaji Telecom Distributors',
      supplierBillNo: 'SBT-GJ-4412',
      billDate: '2026-09-22',
      items: [
        {
          brand: 'Samsung',
          model: 'Galaxy S24 Ultra 5G',
          specs: '12GB / 512GB',
          color: 'Titanium Gray',
          hsn: '85171300',
          qty: 1,
          purchaseRate: 104000,
          gstPercent: 18,
          sellingPrice: 129999,
          imeiList: ['358941098234201'],
        },
        {
          brand: 'Samsung',
          model: 'Galaxy A55 5G',
          specs: '8GB / 128GB',
          color: 'Awesome Iceblue',
          hsn: '85171300',
          qty: 2,
          purchaseRate: 29500,
          gstPercent: 18,
          sellingPrice: 36999,
          imeiList: ['358941098234205', '358941098234206'],
        },
      ],
    },
  },
  {
    id: 'bill-oneplus-supertron',
    title: 'Supertron - OnePlus & Xiaomi Consignment',
    distributorName: 'Supertron Electronics Pvt Ltd',
    billNo: 'SUP-W-9810',
    date: '2026-09-24',
    deviceSummary: 'OnePlus 12 5G (2 Units) & Redmi Note 13 Pro+ (2 Units)',
    itemCount: 4,
    totalAmount: 185260,
    previewSvgDataUri: createInvoiceSvg('Supertron Electronics Pvt Ltd', 'SUP-W-9810', '24-09-2026', [
      {
        desc: 'OnePlus 12 5G (16GB/512GB - Flowy Emerald)',
        hsn: '85171300',
        qty: 2,
        rate: 54000,
        imeis: ['864192067184215', '864192067184216'],
      },
      {
        desc: 'Xiaomi Redmi Note 13 Pro+ 5G (12GB/256GB - Fusion Purple)',
        hsn: '85171300',
        qty: 2,
        rate: 24500,
        imeis: ['860183049102845', '860183049102846'],
      },
    ]),
    extractedMock: {
      supplierName: 'Supertron Electronics Pvt Ltd',
      supplierBillNo: 'SUP-W-9810',
      billDate: '2026-09-24',
      items: [
        {
          brand: 'OnePlus',
          model: 'OnePlus 12 5G',
          specs: '16GB / 512GB',
          color: 'Flowy Emerald',
          hsn: '85171300',
          qty: 2,
          purchaseRate: 54000,
          gstPercent: 18,
          sellingPrice: 64999,
          imeiList: ['864192067184215', '864192067184216'],
        },
        {
          brand: 'Xiaomi',
          model: 'Redmi Note 13 Pro+ 5G',
          specs: '12GB / 256GB',
          color: 'Fusion Purple',
          hsn: '85171300',
          qty: 2,
          purchaseRate: 24500,
          gstPercent: 18,
          sellingPrice: 29999,
          imeiList: ['860183049102845', '860183049102846'],
        },
      ],
    },
  },
];

// Play standard barcode scanner beep sound via Web Audio API
export function playScannerBeep(type: 'success' | 'error' = 'success') {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.connect(gain);
    gain.connect(ctx.destination);

    if (type === 'success') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(1760, ctx.currentTime); // High pitch supermarket scan beep
      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.12);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.12);
    } else {
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(300, ctx.currentTime); // Low error buzz
      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.25);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.25);
    }
  } catch (e) {
    // Ignore audio context errors if browser blocks autoplay
  }
}
