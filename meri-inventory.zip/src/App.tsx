import React, { useState, useEffect } from 'react';
import { InventoryItem, InvoiceRecord, StoreProfile, UserSession, Salesperson } from './types';
import { Navbar } from './components/Navbar';
import { StockInModule } from './components/StockInModule';
import { StockOutModule } from './components/StockOutModule';
import { InventoryManager } from './components/InventoryManager';
import { BillsHistoryModule } from './components/BillsHistoryModule';
import { InvoicePrintTemplate } from './components/InvoicePrintTemplate';
import { AuthAndOnboarding } from './components/AuthAndOnboarding';
import { StoreProfileModal } from './components/StoreProfileModal';
import { PlayStorePublishModal } from './components/PlayStorePublishModal';
import { Wifi, Battery, Signal, Smartphone, Store } from 'lucide-react';

export default function App() {
  const [session, setSession] = useState<UserSession | null>(() => {
    try {
      const saved = localStorage.getItem('meri_inventory_session');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [store, setStore] = useState<StoreProfile>(() => {
    try {
      const saved = localStorage.getItem('meri_inventory_store');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.name && parsed.isConfigured) {
          return parsed;
        }
      }
    } catch {}
    return {
      id: '',
      name: '',
      category: 'RETAIL',
      categoryLabel: 'Exclusive Retail Store (Smartphones & Tech)',
      scale: 'SOLO',
      ownerName: '',
      mobile: '',
      email: '',
      shopNo: '',
      address: '',
      city: '',
      state: 'Gujarat',
      stateCode: '24',
      hasGst: false,
      gstin: '',
      pan: '',
      cin: '',
      phones: [],
      invoicePrefix: 'INV-2026-',
      isConfigured: false,
      setupDate: '',
      salespersons: [],
    };
  });

  const [isStoreSettingsOpen, setIsStoreSettingsOpen] = useState(false);
  const [isPlayStoreModalOpen, setIsPlayStoreModalOpen] = useState(false);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [activeTab, setActiveTab] = useState<'STOCK_IN' | 'STOCK_OUT' | 'INVENTORY' | 'BILLS_HISTORY' | 'INVOICE_VIEW'>('STOCK_OUT');
  const [currentInvoice, setCurrentInvoice] = useState<InvoiceRecord | null>(null);
  const [isMobileFrame, setIsMobileFrame] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [currentTime, setCurrentTime] = useState('');

  // Fetch store profile from server
  const fetchStoreProfile = async (sessionToken?: string, userMobile?: string) => {
    try {
      const token = sessionToken || session?.token;
      const mob = userMobile || session?.mobile;
      const res = await fetch(`/api/store/profile${mob ? `?mobile=${mob}` : ''}`, {
        headers: {
          ...(token ? { 'x-session-token': token } : {}),
          ...(mob ? { 'x-store-mobile': mob } : {}),
        },
      });
      const data = await res.json();
      if (data.success && data.store) {
        setStore(data.store);
        try {
          localStorage.setItem('meri_inventory_store', JSON.stringify(data.store));
        } catch (e) {}
      }
    } catch (e) {
      console.error('Failed to load store profile:', e);
    }
  };

  // Fetch initial inventory
  const fetchInventory = async (sessionToken?: string, userMobile?: string) => {
    try {
      const token = sessionToken || session?.token;
      const mob = userMobile || session?.mobile;
      const res = await fetch(`/api/inventory${mob ? `?mobile=${mob}` : ''}`, {
        headers: {
          ...(token ? { 'x-session-token': token } : {}),
          ...(mob ? { 'x-store-mobile': mob } : {}),
        },
      });
      const data = await res.json();
      if (data.success && Array.isArray(data.items)) {
        setInventory(data.items);
      }
    } catch (e) {
      console.error('Failed to load inventory:', e);
    }
  };

  useEffect(() => {
    if (session?.isLoggedIn) {
      fetchStoreProfile(session.token, session.mobile);
      fetchInventory(session.token, session.mobile);
    }

    const updateClock = () => {
      const now = new Date();
      setCurrentTime(now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false }));
    };
    updateClock();
    const timer = setInterval(updateClock, 10000);
    return () => clearInterval(timer);
  }, [session?.token, session?.mobile]);

  const handleAuthSuccess = (newSession: UserSession, newStore: StoreProfile) => {
    setSession(newSession);
    setStore(newStore);
    try {
      localStorage.setItem('meri_inventory_session', JSON.stringify(newSession));
      localStorage.setItem('meri_inventory_store', JSON.stringify(newStore));
    } catch (e) {
      console.error(e);
    }
    fetchInventory(newSession.token, newSession.mobile);
  };

  const handleLogout = async () => {
    try {
      if (session?.token) {
        await fetch('/api/auth/logout', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ token: session.token, mobile: session.mobile }),
        });
      }
    } catch (e) {
      console.error(e);
    }

    setSession(null);
    setStore({
      id: '',
      name: '',
      category: 'RETAIL',
      categoryLabel: '',
      scale: 'SOLO',
      ownerName: '',
      mobile: '',
      email: '',
      shopNo: '',
      address: '',
      city: '',
      state: 'Gujarat',
      stateCode: '24',
      hasGst: false,
      gstin: '',
      pan: '',
      cin: '',
      phones: [],
      invoicePrefix: 'INV-2026-',
      isConfigured: false,
      setupDate: '',
      salespersons: [],
    });
    setInventory([]);
    setCurrentInvoice(null);
    try {
      localStorage.removeItem('meri_inventory_session');
      localStorage.removeItem('meri_inventory_store');
      localStorage.removeItem('electropos_session');
    } catch (e) {
      console.error(e);
    }
  };

  const handleStockAdded = (newItems: InventoryItem[]) => {
    fetchInventory();
    setActiveTab('INVENTORY');
  };

  const handleSaleCompleted = (invoice: InvoiceRecord) => {
    setCurrentInvoice(invoice);
    fetchInventory();
    setActiveTab('INVOICE_VIEW');
  };

  const handleSalespersonAdded = (newSp: Salesperson) => {
    setStore((prev) => ({
      ...prev,
      salespersons: [...(prev.salespersons || []), newSp],
    }));
  };

  const handleSalespersonUpdated = (updatedSp: Salesperson) => {
    setStore((prev) => ({
      ...prev,
      salespersons: (prev.salespersons || []).map((s) => (s.id === updatedSp.id ? updatedSp : s)),
    }));
  };



  const availableCount = inventory.filter((i) => i.status === 'AVAILABLE').length;
  const soldCount = inventory.filter((i) => i.status === 'SOLD').length;

  // If user is not authenticated or needs initial mobile login / store setup
  if (!session || !session.isLoggedIn || !store.isConfigured || !store.name) {
    return (
      <AuthAndOnboarding
        onAuthSuccess={handleAuthSuccess}
        currentStore={store}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#F2F9F8] flex flex-col font-sans text-slate-900">
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        availableCount={availableCount}
        soldCount={soldCount}
        isMobileFrame={isMobileFrame}
        setIsMobileFrame={setIsMobileFrame}
        soundEnabled={soundEnabled}
        setSoundEnabled={setSoundEnabled}
        hasActiveInvoice={!!currentInvoice}
        store={store}
        onOpenStoreSettings={() => setIsStoreSettingsOpen(true)}
        onOpenPlayStoreModal={() => setIsPlayStoreModalOpen(true)}
        onLogout={handleLogout}
      />

      <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full">
        {/* If Mobile Simulator Frame Mode is toggled */}
        {isMobileFrame ? (
          <div className="flex justify-center items-center py-4">
            <div className="w-full max-w-[420px] bg-slate-950 rounded-[48px] p-3 shadow-2xl border-4 border-slate-800 ring-1 ring-slate-700/50">
              {/* Android Phone Top Speaker & Camera Notch */}
              <div className="w-full flex items-center justify-between px-6 pt-2 pb-1 text-slate-400 text-xs font-mono">
                <span>{currentTime || '09:41'}</span>
                <div className="w-16 h-4 bg-slate-900 rounded-full flex items-center justify-center">
                  <div className="w-2.5 h-2.5 rounded-full bg-slate-800 border border-slate-700" />
                </div>
                <div className="flex items-center gap-1.5">
                  <Signal className="w-3 h-3 text-slate-300" />
                  <Wifi className="w-3 h-3 text-slate-300" />
                  <Battery className="w-3.5 h-3.5 text-slate-300" />
                </div>
              </div>

              {/* Mobile Screen Surface */}
              <div className="bg-slate-100 rounded-[38px] overflow-hidden min-h-[720px] max-h-[820px] overflow-y-auto p-4 flex flex-col">
                <div className="mb-3 flex items-center justify-between border-b border-slate-200 pb-2">
                  <div className="flex items-center gap-1.5">
                    <Store className="w-4 h-4 text-indigo-600" />
                    <span className="text-xs font-black text-slate-900 truncate max-w-[220px]">
                      {store.name || 'My Store'}
                    </span>
                  </div>
                  <button
                    onClick={() => setIsMobileFrame(false)}
                    className="text-[10px] text-indigo-600 font-bold bg-indigo-50 px-2 py-0.5 rounded cursor-pointer"
                  >
                    Expand
                  </button>
                </div>

                {activeTab === 'STOCK_IN' && <StockInModule onStockAdded={handleStockAdded} />}
                {activeTab === 'STOCK_OUT' && (
                  <StockOutModule
                    inventory={inventory}
                    salespersons={store.salespersons || []}
                    onSaleCompleted={handleSaleCompleted}
                    onSalespersonAdded={handleSalespersonAdded}
                    onSalespersonUpdated={handleSalespersonUpdated}
                  />
                )}
                {activeTab === 'INVENTORY' && (
                  <InventoryManager
                    inventory={inventory}
                    onNavigateToStockIn={() => setActiveTab('STOCK_IN')}
                  />
                )}
                {activeTab === 'BILLS_HISTORY' && (
                  <BillsHistoryModule
                    salespersons={store.salespersons || []}
                    onViewInvoice={(invoice) => {
                      setCurrentInvoice(invoice);
                      setActiveTab('INVOICE_VIEW');
                    }}
                  />
                )}

                {activeTab === 'INVOICE_VIEW' && currentInvoice && (
                  <InvoicePrintTemplate invoice={currentInvoice} onBack={() => setActiveTab('STOCK_OUT')} />
                )}
              </div>

              {/* Home indicator pill */}
              <div className="w-28 h-1 bg-slate-700 rounded-full mx-auto mt-2" />
            </div>
          </div>
        ) : (
          /* Full POS Terminal View */
          <div>
            {activeTab === 'STOCK_IN' && <StockInModule onStockAdded={handleStockAdded} />}
            {activeTab === 'STOCK_OUT' && (
              <StockOutModule
                inventory={inventory}
                salespersons={store.salespersons || []}
                onSaleCompleted={handleSaleCompleted}
                onSalespersonAdded={handleSalespersonAdded}
                onSalespersonUpdated={handleSalespersonUpdated}
              />
            )}
            {activeTab === 'INVENTORY' && (
              <InventoryManager
                inventory={inventory}
                onNavigateToStockIn={() => setActiveTab('STOCK_IN')}
              />
            )}
            {activeTab === 'BILLS_HISTORY' && (
              <BillsHistoryModule
                salespersons={store.salespersons || []}
                onViewInvoice={(invoice) => {
                  setCurrentInvoice(invoice);
                  setActiveTab('INVOICE_VIEW');
                }}
              />
            )}

            {activeTab === 'INVOICE_VIEW' && currentInvoice && (
              <InvoicePrintTemplate invoice={currentInvoice} onBack={() => setActiveTab('STOCK_OUT')} />
            )}
          </div>
        )}
      </main>

      {/* Store Profile & Settings Modal */}
      <StoreProfileModal
        store={store}
        isOpen={isStoreSettingsOpen}
        onClose={() => setIsStoreSettingsOpen(false)}
        onUpdate={(updated) => {
          setStore(updated);
          try {
            localStorage.setItem('meri_inventory_store', JSON.stringify(updated));
          } catch (e) {}
        }}
      />

      {/* Google Play Store / AAB Publish Modal */}
      <PlayStorePublishModal
        isOpen={isPlayStoreModalOpen}
        onClose={() => setIsPlayStoreModalOpen(false)}
        publicUrl="https://ais-pre-7ls27yveki4ijbebws4sm3-965588620834.asia-southeast1.run.app"
      />
    </div>
  );
}
